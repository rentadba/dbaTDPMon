RAISERROR('Create procedure: [dbo].[usp_logEventMessage]', 10, 1) WITH NOWAIT
GO---
IF  EXISTS (
	    SELECT * 
	      FROM sysobjects 
	     WHERE id = OBJECT_ID(N'[dbo].[usp_logEventMessage]') 
	       AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_logEventMessage]
GO

GO
CREATE PROCEDURE [dbo].[usp_logEventMessage]
		@projectCode			[sysname]=NULL,
		@sqlServerName			[sysname]=NULL,
		@dbName					[sysname] = NULL,
		@objectName				[nvarchar](512) = NULL,
		@childObjectName		[sysname] = NULL,
		@module					[sysname],
		@eventName				[nvarchar](256) = NULL,
		@parameters				[nvarchar](512) = NULL,			/* may contain the attach file name */
		@eventMessage			[varchar](8000) = NULL,
		@eventType				[smallint]=1,	/*	0 - info
													1 - alert 
													2 - job-history
													3 - report-html
													4 - action
												*/
		@recipientsList			[nvarchar](1024) = NULL,
		@isEmailSent			[bit]=0,
		@isFloodControl			[bit]=0
AS

-- ============================================================================
-- Author			 : Andrei STEFAN (danandrei.stefan@gmail.com)
-- Create date		 : 05.11.2014
-- Module			 : Database Analysis & Performance Monitoring
-- ============================================================================

SET NOCOUNT ON

DECLARE @projectID					[smallint],
		@instanceID					[smallint]

-----------------------------------------------------------------------------------------------------
--get default project code
IF @projectCode IS NULL
	SELECT @projectCode = [value]
	FROM [dbo].[appConfigurations]
	WHERE [name] = 'Default project code'

SELECT @projectID = [id]
FROM [dbo].[catalogProjects]
WHERE [code] = @projectCode 

-----------------------------------------------------------------------------------------------------
SELECT  @instanceID = [id] 
FROM	[dbo].[catalogInstanceNames]  
WHERE	[name] = @sqlServerName
		AND [project_id] = @projectID

-----------------------------------------------------------------------------------------------------
--xml corrections
SET @eventMessage = REPLACE(@eventMessage, CHAR(38), CHAR(38) + 'amp;')

-----------------------------------------------------------------------------------------------------
INSERT	INTO [dbo].[logEventMessages]([project_id], [instance_id], [event_date_utc], [module], [parameters], [event_name], [database_name], [object_name], [child_object_name], [message], [send_email_to], [event_type], [is_email_sent], [flood_control])
		SELECT @projectID, @instanceID, GETUTCDATE(), @module, @parameters, @eventName, @dbName, @objectName, @childObjectName, @eventMessage, @recipientsList, @eventType, @isEmailSent, @isFloodControl

RETURN 0
GO

