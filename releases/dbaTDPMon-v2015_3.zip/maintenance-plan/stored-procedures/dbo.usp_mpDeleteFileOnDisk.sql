RAISERROR('Create procedure: [dbo].[usp_mpDeleteFileOnDisk]', 10, 1) WITH NOWAIT
GO
IF  EXISTS (
	    SELECT * 
	      FROM sysobjects 
	     WHERE id = OBJECT_ID(N'[dbo].[usp_mpDeleteFileOnDisk]') 
	       AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_mpDeleteFileOnDisk]
GO

CREATE PROCEDURE [dbo].[usp_mpDeleteFileOnDisk]
		@sqlServerName			[sysname],
		@fileName				[nvarchar](1024),
		@executionLevel			[tinyint] = 0,
		@debugMode				[bit] = 0
AS

-- ============================================================================
-- Author			 : Andrei STEFAN (danandrei.stefan@gmail.com)
-- Create date		 : 10.03.2015
-- Module			 : Database Analysis & Performance Monitoring
-- ============================================================================

DECLARE   @queryToRun				[nvarchar](1024)
		, @serverToRun				[nvarchar](512)
		, @confXPCMDSHELL			[bit]
		, @confXPCMDSHELLChanged	[bit]
		, @errorCode				[int]

DECLARE	  @serverEdition			[sysname]
		, @serverVersionStr			[sysname]
		, @serverVersionNum			[numeric](9,6)
		, @nestedExecutionLevel		[tinyint]


SET NOCOUNT ON

/*-------------------------------------------------------------------------------------------------------------------------------*/
IF object_id('#serverPropertyConfig') IS NOT NULL DROP TABLE #serverPropertyConfig
CREATE TABLE #serverPropertyConfig
			(
				[value]			[sysname]	NULL
			)

IF object_id('#fileExists') IS NOT NULL DROP TABLE #fileExists
CREATE TABLE #fileExists
			(
				[file_exists]				[bit]	NULL,
				[file_is_directory]			[bit]	NULL,
				[parent_directory_exists]	[bit]	NULL
			)

-----------------------------------------------------------------------------------------
--get destination server running version/edition
SET @nestedExecutionLevel = @executionLevel + 1
EXEC [dbo].[usp_getSQLServerVersion]	@sqlServerName			= @sqlServerName,
										@serverEdition			= @serverEdition OUT,
										@serverVersionStr		= @serverVersionStr OUT,
										@serverVersionNum		= @serverVersionNum OUT,
										@executionLevel			= @nestedExecutionLevel,
										@debugMode				= @debugMode

/*-------------------------------------------------------------------------------------------------------------------------------*/
/* check if folderName exists																									 */
IF @sqlServerName=@@SERVERNAME
		SET @queryToRun = N'master.dbo.xp_fileexist ''' + @fileName + ''''
else
		SET @queryToRun = N'SELECT * FROM OPENQUERY([' + @sqlServerName + N'], ''SET FMTONLY OFF; EXEC master.dbo.xp_fileexist ''''' + @fileName + ''''';'')x'

IF @debugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
INSERT	INTO #fileExists([file_exists], [file_is_directory], [parent_directory_exists])
		EXEC (@queryToRun)


IF (SELECT [file_exists] FROM #fileExists)=1
	begin
		SET @queryToRun= 'Deleting file: "' + @fileName + '"'
		EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 0, @stopExecution=0

		IF @serverVersionNum>=9
			begin
				/*-------------------------------------------------------------------------------------------------------------------------------*/
				/* check if xp_cmdshell is enabled or should be enabled																			 */
				SET @confXPCMDSHELLChanged=0

				SET @queryToRun = N''
				SET @queryToRun = @queryToRun + 'SELECT CAST([value] AS [sysname]) AS [value] FROM sys.configurations WHERE [name]=''xp_cmdshell'''
				SET @queryToRun = [dbo].[ufn_formatSQLQueryForLinkedServer](@sqlServerName, @queryToRun)
				IF @debugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

				INSERT	INTO #serverPropertyConfig([value])
						EXEC (@queryToRun)
		
				SELECT @confXPCMDSHELL=CONVERT([bit], [value])
				FROM #serverPropertyConfig


				/*-------------------------------------------------------------------------------------------------------------------------------*/
				IF @confXPCMDSHELL=0
					begin
						SET @queryToRun  = N'sp_configure ''xp_cmdshel'', 1; RECONFIGURE WITH OVERRIDE;'
						IF @debugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

						SET @nestedExecutionLevel = @executionLevel + 1
						EXEC @errorCode = [dbo].[usp_sqlExecuteAndLog]	@sqlServerName	= @sqlServerName,
																		@dbName			= NULL,
																		@objectName		= NULL,
																		@module			= 'dbo.usp_mpDeleteFileOnDisk',
																		@eventName		= 'configuration option change',
																		@queryToRun  	= @queryToRun,
																		@flgOptions		= 0,
																		@executionLevel	= @nestedExecutionLevel,
																		@debugMode		= @debugMode						

						SET @queryToRun = N''
						SET @queryToRun = @queryToRun + 'SELECT CAST([value] AS [sysname]) AS [value]  FROM sys.configurations WHERE [name]=''xp_cmdshell'''
						SET @queryToRun = [dbo].[ufn_formatSQLQueryForLinkedServer](@sqlServerName, @queryToRun)
						IF @debugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

						DELETE FROM #serverPropertyConfig
						INSERT	INTO #serverPropertyConfig([value])
								EXEC (@queryToRun)
		
						SELECT @confXPCMDSHELL=CONVERT([bit], [value])
						FROM #serverPropertyConfig

						IF @confXPCMDSHELL=0 
							begin
								set @queryToRun='xp_cmdshell component is turned off. Cannot continue'
								EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=1
								RETURN 1
							end		
						ELSE
							SET @confXPCMDSHELLChanged=1
					end
			end

		/*-------------------------------------------------------------------------------------------------------------------------------*/
		/* deleting file     																											 */
		SET @queryToRun = N'DEL "' + @fileName + '"'
		SET @serverToRun = N'[' + @sqlServerName + '].master.dbo.xp_cmdshell'
		IF @debugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
		EXEC @serverToRun @queryToRun , NO_OUTPUT


		/*-------------------------------------------------------------------------------------------------------------------------------*/
		IF @serverVersionNum>=9
			begin
				IF @confXPCMDSHELLChanged=1
					begin
						SET @queryToRun  = N'sp_configure ''xp_cmdshel'', 0; RECONFIGURE WITH OVERRIDE;'
						IF @debugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

						SET @nestedExecutionLevel = @executionLevel + 1
						EXEC @errorCode = [dbo].[usp_sqlExecuteAndLog]	@sqlServerName	= @sqlServerName,
																		@dbName			= NULL,
																		@objectName		= NULL,
																		@module			= 'dbo.usp_mpDeleteFileOnDisk',
																		@eventName		= 'configuration option change',
																		@queryToRun  	= @queryToRun,
																		@flgOptions		= 0,
																		@executionLevel	= @nestedExecutionLevel,
																		@debugMode		= @debugMode						
					end
			end

		/*-------------------------------------------------------------------------------------------------------------------------------*/
		/* check if file still exists																									 */
		IF @sqlServerName=@@SERVERNAME
				SET @queryToRun = N'master.dbo.xp_fileexist ''' + @fileName + ''''
		else
				SET @queryToRun = N'SELECT * FROM OPENQUERY([' + @sqlServerName + N'], ''SET FMTONLY OFF; EXEC master.dbo.xp_fileexist ''''' + @fileName + ''''';'')x'

		IF @debugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
		DELETE FROM #fileExists
		INSERT	INTO #fileExists([file_exists], [file_is_directory], [parent_directory_exists])
				EXEC (@queryToRun)

		IF (SELECT [file_exists] FROM #fileExists)=1
			begin
				SET @queryToRun = N'ERROR: File could not be deleted.'
				EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
				RETURN 1
			end
		ELSE
			begin
				SET @queryToRun = N'File successfully deleted.'
				EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
			end
	end
/*
ELSE
	begin
		SET @queryToRun = N'File does not exists. Nothing to do.'
		EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
	end
*/
RETURN 0
GO

