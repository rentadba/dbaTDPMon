-- ============================================================================
-- Author			 : Andrei STEFAN
-- Create date		 : 10.11.2009
-- Module			 : Database Analysis & Performance Monitoring
-- ============================================================================

-----------------------------------------------------------------------------------------------------
--
-----------------------------------------------------------------------------------------------------
RAISERROR('Create view : [dbo].[vw_logInternalMessages]', 10, 1) WITH NOWAIT
GO
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[vw_logInternalMessages]') AND type in (N'V'))
DROP VIEW [dbo].[vw_logInternalMessages]
GO

CREATE VIEW [dbo].[vw_logInternalMessages]
AS
SELECT    lim.[id]		AS [log_id]
		, cin.[project_id] 
		, cin.[id]		AS [instance_id]
		, cin.[name]	AS [instance_name]
		, lim.[message_id]
		, dlMsg.[object_name] 
		, dlMsg.[message] 
		, lim.[log_time]
		, lim.[duration_ms]
FROM [dbo].[logInternalMessages]			 lim
INNER JOIN [dbo].[catalogInstanceNames]		 cin	ON cin.[id] = lim.[instance_id] AND cin.[project_id] = lim.[project_id]
INNER JOIN [dbo].[catalogInternalLogMessage] dlMsg	ON dlMsg.[id] = lim.[message_id] 
GO

