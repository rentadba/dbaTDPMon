-- ============================================================================
-- Author			 : Andrei STEFAN
-- Create date		 : 21.02.2011
-- Module			 : Database Analysis & Performance Monitoring
-- ============================================================================

RAISERROR('Create procedure: [dbo].[usp_logInternalMessage]', 10, 1) WITH NOWAIT
GO
IF  EXISTS (
	    SELECT * 
	      FROM sysobjects 
	     WHERE id = OBJECT_ID(N'[dbo].[usp_logInternalMessage]') 
	       AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_logInternalMessage]
GO

CREATE PROCEDURE [dbo].[usp_logInternalMessage]
		@projectID				[smallint],
		@instanceID				[smallint],
		@ObjectName				[sysname],
		@MessageType			[nvarchar](256),
		@StartTime				[datetime] = NULL,
		@EndTime				[datetime] = NULL,
		@DurationMS				[int],
		@LogTime				[datetime] = NULL
AS

SET NOCOUNT ON

DECLARE @MessageID				[int],
		@strMessage				[nvarchar](512),
		@flgOptions				[int]

-- { sql_statement | statement_block }
BEGIN TRY
	-----------------------------------------------------------------------------------------------------
	--compute duration
	IF @DurationMS IS NULL
		SELECT @DurationMS = [dbo].[ufn_getMilisecondsBetweenDates](ISNULL(@StartTime, GETUTCDATE()), ISNULL(@EndTime, GETUTCDATE()))

	--default log_time = GETUTCDATE()
	SET @LogTime = ISNULL(@LogTime, GETUTCDATE())

	-----------------------------------------------------------------------------------------------------
	--get configuration options
	SELECT	@flgOptions =	SUM([flg_options])
	FROM (
			SELECT  CASE WHEN [name] = 'Print internal messages' AND UPPER([value]) ='TRUE' THEN 1 ELSE 0 END + 
					CASE WHEN [name] = 'Log internal messages'   AND UPPER([value]) ='TRUE' THEN 2 ELSE 0 END AS [flg_options]
			FROM [dbo].[appConfigurations]
			WHERE [name] IN ('Print internal messages', 'Log internal messages')
		 )x

	-----------------------------------------------------------------------------------------------------
	--insert message to table
	-----------------------------------------------------------------------------------------------------
	IF @flgOptions & 2 = 2
		begin
			--get message ID
			SELECT @MessageID = [id]
			FROM	[dbo].[catalogInternalLogMessage]
			WHERE	[object_name] = @ObjectName
					AND [message] = @MessageType
			
			IF @MessageID IS NULL
				begin
					INSERT	INTO [dbo].[catalogInternalLogMessage]([object_name], [message])
							SELECT @ObjectName, @MessageType
					
					SET @MessageID=@@IDENTITY
				end

			-----------------------------------------------------------------------------------------------------
			--insert message detail
			INSERT	INTO [dbo].[logInternalMessages] ([project_id], [instance_id], [message_id], [log_time], [duration_ms])
					SELECT @projectID, @instanceID, @MessageID, @LogTime, @DurationMS
		end
		
	-----------------------------------------------------------------------------------------------------
	--print message to output
	-----------------------------------------------------------------------------------------------------
	IF @flgOptions & 1 = 1
		begin
			SET @strMessage = CONVERT([nvarchar](24), @LogTime, 121) + N'	' + @ObjectName + N' -> ' + @MessageType + N' (' + CAST(@DurationMS AS [nvarchar]) + N' ms)'
			
			PRINT @strMessage
		end		
END TRY

BEGIN CATCH
--variable used for raise errors
	DECLARE	@ErrorMessage			[nvarchar](4000),
			@ErrorNumber			[int],
			@ErrorSeverity			[int],
			@ErrorState				[int],
			@ErrorLine				[int],
			@ErrorProcedure			[nvarchar](200);

    -- Assign variables to error-handling functions that 
    -- capture information for RAISERROR.
    SELECT 
        @ErrorNumber = ERROR_NUMBER(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = CASE WHEN ERROR_STATE() BETWEEN 1 AND 127 THEN ERROR_STATE() ELSE 1 END ,
        @ErrorLine = ERROR_LINE(),
        @ErrorProcedure = ISNULL(ERROR_PROCEDURE(), '-');
	-- Building the message string that will contain original
    -- error information.
    SELECT @ErrorMessage = 
        N'Error %d, Level %d, State %d, Procedure %s, Line %d, ' + 
            'Message: '+ ERROR_MESSAGE();
    -- Raise an error: msg_str parameter of RAISERROR will contain
    -- the original error information.
    RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        @ErrorState,               
        @ErrorNumber,    -- parameter: original error number.
        @ErrorSeverity,  -- parameter: original error severity.
        @ErrorState,     -- parameter: original error state.
        @ErrorProcedure, -- parameter: original error procedure name.
        @ErrorLine       -- parameter: original error line number.
        );

        -- Test XACT_STATE:
        -- If 1, the transaction is committable.
        -- If -1, the transaction is uncommittable and should 
        --     be rolled back.
        -- XACT_STATE = 0 means that there is no transaction and
        --     a COMMIT or ROLLBACK would generate an error.

    -- Test if the transaction is uncommittable.
    IF (XACT_STATE()) = -1
    BEGIN
        PRINT
            N'The transaction is in an uncommittable state.' +
            'Rolling back transaction.'
        ROLLBACK TRANSACTION 
   END;

END CATCH
GO
