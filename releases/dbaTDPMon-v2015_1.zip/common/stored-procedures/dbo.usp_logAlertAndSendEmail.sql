-- ============================================================================
-- Author			 : Andrei STEFAN
-- Create date		 : 05.11.2014
-- Module			 : Database Analysis & Performance Monitoring
-- ============================================================================

RAISERROR('Create procedure: [dbo].[usp_logAlertAndSendEmail]', 10, 1) WITH NOWAIT
GO---
IF  EXISTS (
	    SELECT * 
	      FROM sys.objects 
	     WHERE object_id = OBJECT_ID(N'[dbo].[usp_logAlertAndSendEmail]') 
	       AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_logAlertAndSendEmail]
GO

CREATE PROCEDURE [dbo].[usp_logAlertAndSendEmail]
		@projectCode			[sysname]=NULL,
		@sqlServerName			[sysname]=NULL,
		@module					[varchar](32),
		@eventName				[nvarchar](256),
		@parameters				[nvarchar](512) = NULL,			/* may contain the attach file name */
		@alertMessage			[nvarchar](max) = NULL,
		@dbMailProfileName		[sysname] = NULL,
		@recipientsList			[nvarchar](1024) = NULL,
		@eventType				[smallint]=1	/*	1 - Alert 
													2 - SQL Server Agent job status
													3 - Report
												*/
AS

SET NOCOUNT ON

DECLARE @projectID					[smallint],
		@instanceID					[smallint],		
		@alertFrequency				[int],
		@alertAlreadySent			[int],

		@HTMLBody					[nvarchar](max),
		@emailSubject				[nvarchar](256),
		@queryToRun					[nvarchar](max),
		@ReturnValue				[int],
		@ErrMessage					[nvarchar](256),
		@SnapshotStartTime			[datetime],
		@SnapshotStopTime			[datetime],
		@clientName					[nvarchar](260)

-- { sql_statement | statement_block }
BEGIN TRY
	SET @SnapshotStartTime = GETUTCDATE()
	SET @ReturnValue=1

	-----------------------------------------------------------------------------------------------------
	SELECT @projectID = [id]
	FROM [dbo].[catalogProjects]
	WHERE [code] = @projectCode 

	IF @projectID IS NULL
		begin
			PRINT N'--WARNING: The value specified for Project ID is not valid.'
		end

	-----------------------------------------------------------------------------------------------------
	SELECT  @instanceID = [id] 
	FROM	[dbo].[catalogInstanceNames]  
	WHERE	[name] = @sqlServerName
			AND [project_id] = @projectID

	IF @instanceID IS NULL 
		begin
			PRINT N'--WARNING: Specified server name is not defined in catalog tables.'
		end
		
	-----------------------------------------------------------------------------------------------------
	SET @ErrMessage='-- sending alert for: [' + @sqlServerName + ']'
	RAISERROR(@ErrMessage, 10, 1) WITH NOWAIT
		
	-----------------------------------------------------------------------------------------------------
	--
	-----------------------------------------------------------------------------------------------------
	--get default database mail profile name from configuration table
	IF UPPER(@dbMailProfileName)='NULL'
		SET @dbMailProfileName = NULL
		
	IF @dbMailProfileName IS NULL
		SELECT @dbMailProfileName=[value] 
		FROM [dbo].[appConfigurations] 
		WHERE [name]='Database Mail profile name to use for sending emails'

	IF @recipientsList = ''		SET @recipientsList = NULL
	IF @dbMailProfileName = ''	SET @dbMailProfileName = NULL


	IF @recipientsList IS NULL
		SELECT @recipientsList=[value] 
		FROM [dbo].[appConfigurations] 
		WHERE  (@eventType=1 AND [name]='Default recipients list - Alerts (semicolon separated)')
			OR (@eventType=2 AND [name]='Default recipients list - Job Status (semicolon separated)')
			OR (@eventType=3 AND [name]='Default recipients list - Reports (semicolon separated)')
														

	-----------------------------------------------------------------------------------------------------
	--get alert repeat frequency, default every 60 minutes
	-----------------------------------------------------------------------------------------------------
	BEGIN TRY
		SELECT @alertFrequency = [value]
		FROM [dbo].[appConfigurations]
		WHERE [name]='Alert repeat interval (minutes)'
	END TRY
	BEGIN CATCH
		SET @alertFrequency = NULL
	END CATCH

	SELECT @alertFrequency = ISNULL(@alertFrequency, 60)


	-----------------------------------------------------------------------------------------------------
	--check if alert should be sent
	-----------------------------------------------------------------------------------------------------
	SET @alertAlreadySent=0
	IF @projectID IS NOT NULL AND @instanceID IS NOT NULL
		SELECT @alertAlreadySent=COUNT(*)
		FROM [dbo].[logAlertMessages]
		WHERE	[instance_id] = @instanceID
				AND [project_id] = @projectID
				AND [module] = @module
				AND [event_name] = @eventName
				AND ISNULL([parameters], '') = ISNULL(@parameters, '')
				AND DATEDIFF(mi, [event_date], GETUTCDATE()) BETWEEN 0 AND @alertFrequency

	-----------------------------------------------------------------------------------------------------
	--log messages
	-----------------------------------------------------------------------------------------------------
	SET @SnapshotStopTime = GETUTCDATE()
	IF @projectID IS NOT NULL
		EXEC [dbo].[usp_logInternalMessage]	@projectID				= @projectID,
											@instanceID				= NULL,
											@ObjectName				= 'dbo.usp_logAlertAndSendEmail',
											@MessageType			= 'alert flood control',
											@StartTime				= @SnapshotStartTime,
											@EndTime				= @SnapshotStopTime,
											@DurationMS				= NULL,	
											@LogTime				= NULL		
	

	-----------------------------------------------------------------------------------------------------
	--
	-----------------------------------------------------------------------------------------------------
	IF @alertAlreadySent=0
		begin
			SET @SnapshotStartTime = GETUTCDATE()
			
			SET @projectCode = ISNULL(@projectCode, 'N/A')
		
			SET @emailSubject = CASE WHEN @eventType=1 THEN 'dbaTDPMon Alert ' + ' on ' + CASE WHEN @projectID IS NOT NULL THEN '[' + @projectCode + ']' ELSE N'' END + '[' +  @sqlServerName + ']: ' + @eventName
									 WHEN @eventType=2 THEN 'dbaTDPMon Job ' + ' on ' + CASE WHEN @projectID IS NOT NULL THEN '[' + @projectCode + ']' ELSE N'' END + '[' +  @sqlServerName + ']: ' + @eventName
									 WHEN @eventType=3 THEN 'dbaTDPMon Report ' + ' on ' + CASE WHEN @projectID IS NOT NULL THEN '[' + @projectCode + ']' ELSE N'' END + '[' +  @sqlServerName + ']: ' + @eventName
								END				

			SET @HTMLBody =N''
				
			SET @HTMLBody = @HTMLBody + @alertMessage + N'<HR><P STYLE="font-family: Arial, Tahoma; font-size:10px;">This email is send by [' + @@SERVERNAME + N'] SQL Server instance name.<br>
							Generated by dbaTDPMon.<br><P>'
				
			-----------------------------------------------------------------------------------------------------
			IF @recipientsList IS NOT NULL AND @dbMailProfileName IS NOT NULL
				begin
					-----------------------------------------------------------------------------------------------------
					--sending email using dbmail
					-----------------------------------------------------------------------------------------------------
					IF @eventType in (2,3) AND @parameters IS NOT NULL
						EXEC msdb.dbo.sp_send_dbmail
								  @profile_name		= @dbMailProfileName
								, @recipients		= @recipientsList
								, @subject			= @emailSubject
								, @body				= @HTMLBody
								, @file_attachments = @parameters
								, @body_format		= 'HTML'
					ELSE
						EXEC msdb.dbo.sp_send_dbmail
							  @profile_name		= @dbMailProfileName
							, @recipients		= @recipientsList
							, @subject			= @emailSubject
							, @body				= @HTMLBody
							, @file_attachments = NULL
							, @body_format		= 'HTML'
					
					IF @projectID IS NOT NULL AND @instanceID IS NOT NULL
						INSERT	INTO [dbo].[logAlertMessages]([project_id], [instance_id], [event_date], [module], [parameters], [event_name], [message], [send_email_to], [is_email_sent])
								SELECT @projectID, @instanceID, GETUTCDATE(), @module, @parameters, @eventName, @alertMessage, @recipientsList, 1
				end

			-----------------------------------------------------------------------------------------------------
			--log messages
			-----------------------------------------------------------------------------------------------------
			SET @SnapshotStopTime = GETUTCDATE()
			IF @projectID IS NOT NULL
				EXEC [dbo].[usp_logInternalMessage]	@projectID				= @projectID,
													@instanceID				= NULL,
													@ObjectName				= 'dbo.usp_logAlertAndSendEmail',
													@MessageType			= 'alert sent to email',
													@StartTime				= @SnapshotStartTime,
													@EndTime				= @SnapshotStopTime,
													@DurationMS				= NULL,	
													@LogTime				= NULL
		end
	ELSE
		PRINT 'Alert already sent.'
	
	-----------------------------------------------------------------------------------------------------
END TRY

BEGIN CATCH
DECLARE 
        @ErrorMessage    NVARCHAR(4000),
        @ErrorNumber     INT,
        @ErrorSeverity   INT,
        @ErrorState      INT,
        @ErrorLine       INT,
        @ErrorProcedure  NVARCHAR(200);
    -- Assign variables to error-handling functions that 
    -- capture information for RAISERROR.
    SELECT 
        @ErrorNumber = ERROR_NUMBER(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = CASE WHEN ERROR_STATE() BETWEEN 1 AND 127 THEN ERROR_STATE() ELSE 1 END ,
        @ErrorLine = ERROR_LINE(),
        @ErrorProcedure = ISNULL(ERROR_PROCEDURE(), '-');
	-- Building the message string that will contain original
    -- error information.
    SELECT @ErrorMessage = 
        N'Error %d, Level %d, State %d, Procedure %s, Line %d, ' + 
            'Message: '+ ERROR_MESSAGE();
    -- Raise an error: msg_str parameter of RAISERROR will contain
    -- the original error information.
    RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        @ErrorState,               
        @ErrorNumber,    -- parameter: original error number.
        @ErrorSeverity,  -- parameter: original error severity.
        @ErrorState,     -- parameter: original error state.
        @ErrorProcedure, -- parameter: original error procedure name.
        @ErrorLine       -- parameter: original error line number.
        );

        -- Test XACT_STATE:
        -- If 1, the transaction is committable.
        -- If -1, the transaction is uncommittable and should 
        --     be rolled back.
        -- XACT_STATE = 0 means that there is no transaction and
        --     a COMMIT or ROLLBACK would generate an error.

    -- Test if the transaction is uncommittable.
    IF (XACT_STATE()) = -1
    BEGIN
        PRINT
            N'The transaction is in an uncommittable state.' +
            'Rolling back transaction.'
        ROLLBACK TRANSACTION 
   END;

END CATCH

RETURN @ReturnValue
GO
