-- ============================================================================
-- Author			 : Andrei STEFAN
-- Create date		 : 10.11.2009
-- Module			 : Database Analysis & Performance Monitoring
-- ============================================================================

-----------------------------------------------------------------------------------------------------
RAISERROR('Create table: [dbo].[logInternalMessages]', 10, 1) WITH NOWAIT
GO
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[logInternalMessages]') AND type in (N'U'))
DROP TABLE [dbo].[logInternalMessages]
GO
CREATE TABLE [dbo].[logInternalMessages]
(
	[id]										[bigint] IDENTITY (1,1)NOT NULL,
	[project_id]								[smallint]			NOT NULL,
	[instance_id]								[smallint]			NULL,
	[message_id]								[int]				NOT NULL,
	[log_time]									[datetime]			NOT NULL CONSTRAINT [DF_logInternalMessages_LogTime]  DEFAULT (GETUTCDATE()),
	[duration_ms]								[int]				NOT NULL,
	CONSTRAINT [PK_logInternalMessages] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [FG_Statistics_Data],
	CONSTRAINT [FK_logInternalMessages_catalogProjects] FOREIGN KEY 
	(
		[project_id]
	) 
	REFERENCES [dbo].[catalogProjects] 
	(
		[id]
	),
	CONSTRAINT [FK_logInternalMessages_catalogInstanceNames] FOREIGN KEY 
	(
		[instance_id],
		[project_id]
	) 
	REFERENCES [dbo].[catalogInstanceNames] 
	(
		[id],
		[project_id]
	),
	CONSTRAINT [FK_logInternalMessages_catalogInternalLogMessage] FOREIGN KEY 
		(
			[message_id]
		) 
		REFERENCES [dbo].[catalogInternalLogMessage]
		(
			[id]
		)
) ON [FG_Statistics_Data]
GO


CREATE INDEX [IX_logInternalMessagess_InstanceID] ON [dbo].[logInternalMessages]([instance_id], [project_id]) ON [FG_Statistics_Index]
GO
CREATE INDEX [IX_logInternalMessages_ProjecteID] ON [dbo].[logInternalMessages]([project_id]) ON [FG_Statistics_Index]
GO
CREATE INDEX [IX_logInternalMessages_MessageID] ON [dbo].[logInternalMessages]([message_id]) ON [FG_Statistics_Index]
GO

