-- ============================================================================
-- Author			 : Andrei STEFAN
-- Create date		 : 10.11.2009
-- Module			 : Database Analysis & Performance Monitoring
-- ============================================================================

-----------------------------------------------------------------------------------------------------
RAISERROR('Create table: [dbo].[catalogInternalLogMessage]', 10, 1) WITH NOWAIT
GO
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[catalogInternalLogMessage]') AND type in (N'U'))
DROP TABLE [dbo].[catalogInternalLogMessage]
GO
CREATE TABLE [dbo].[catalogInternalLogMessage]
(
	[id]										[int] IDENTITY (1,1)NOT NULL,
	[object_name]								[sysname]			NOT NULL,
	[message]									[nvarchar]	(256)	NOT NULL,
	CONSTRAINT [PK_catalogInternalLogMessage] PRIMARY KEY  CLUSTERED 
	(
		[id]
	)  ON [PRIMARY],
	CONSTRAINT [IX_catalogInternalLogMessage_Message] UNIQUE  NONCLUSTERED 
	(
		  [object_name]
		, [message]
	)  ON [PRIMARY]	
) ON [PRIMARY]
GO
