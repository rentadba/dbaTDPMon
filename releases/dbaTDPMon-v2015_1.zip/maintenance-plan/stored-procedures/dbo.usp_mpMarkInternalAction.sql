-- ============================================================================
-- Author			 : Andrei STEFAN
-- Create date		 : 06.02.2015
-- Module			 : Database Analysis & Performance Monitoring
-- ============================================================================

RAISERROR('Create procedure: [dbo].[usp_mpMarkInternalAction]', 10, 1) WITH NOWAIT
GO
IF  EXISTS (
	    SELECT * 
	      FROM sys.objects 
	     WHERE object_id = OBJECT_ID(N'[dbo].[usp_mpMarkInternalAction]') 
	       AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_mpMarkInternalAction]
GO

CREATE PROCEDURE [dbo].[usp_mpMarkInternalAction]
		@actionName				[sysname],
		@flgOperation			[tinyint] = 1, /*	1 - insert action 
													2 - delete action
												*/
		@value1					[sysname] = NULL,
		@value2					[sysname] = NULL,
		@value3					[sysname] = NULL,
		@value4					[sysname] = NULL
AS

SET NOCOUNT ON

--insert action
IF @flgOperation = 1
	begin
		INSERT	INTO [dbo].[statsMaintenancePlanInternals]([name], [value1], [value2], [value3], [value4])
				SELECT @actionName, @value1, @value2, @value3, @value4
	end

--delete action
IF @flgOperation = 2
	begin
		IF @value1 <> '%'
			DELETE	FROM [dbo].[statsMaintenancePlanInternals]
			WHERE	[session_id] = @@SPID
					AND [name] = @actionName
					AND ([value1] = @value1 OR ([value1] IS NULL AND @value1 IS NULL))
					AND ([value2] = @value2 OR ([value2] IS NULL AND @value2 IS NULL))
					AND ([value3] = @value3 OR ([value3] IS NULL AND @value3 IS NULL))
					AND ([value4] = @value4 OR ([value4] IS NULL AND @value4 IS NULL))
		ELSE
			DELETE	FROM [dbo].[statsMaintenancePlanInternals]
			WHERE	[session_id] = @@SPID
					AND [name] = @actionName

	end
GO
