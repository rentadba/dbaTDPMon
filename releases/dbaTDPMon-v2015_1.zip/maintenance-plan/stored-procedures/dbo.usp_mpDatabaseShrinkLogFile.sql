-- ============================================================================
-- Author			 : Andrei STEFAN
-- Create date		 : 01.03.2010
-- Module			 : Database Maintenance Scripts
--					 : SQL Server 2000/2005/2008/2008R2/2012+
-- ============================================================================

-----------------------------------------------------------------------------------------
-- Input Parameters:
--		@SQLServerName	- name of SQL Server instance to analyze
--		@DBName			- database to be analyzed
--		@DebugMode:		 1 - print dynamic SQL statements 
--						 0 - no statements will be displayed (default)
-----------------------------------------------------------------------------------------
-- Return : 
-- 1 : Succes  -1 : Fail 
-----------------------------------------------------------------------------------------
RAISERROR('Create procedure: [dbo].[usp_mpDatabaseShrinkLogFile]', 10, 1) WITH NOWAIT
GO
IF  EXISTS (
	    SELECT * 
	      FROM sysobjects 
	     WHERE id = OBJECT_ID(N'[dbo].[usp_mpDatabaseShrinkLogFile]') 
	       AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_mpDatabaseShrinkLogFile]
GO

-----------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_mpDatabaseShrinkLogFile]
		@SQLServerName		[sysname],
		@DBName				[sysname] = NULL,
		@executionLevel		[tinyint] = 0,
		@DebugMode			[bit] = 0
AS

SET NOCOUNT ON

DECLARE		@queryToRun    			[nvarchar](4000),
			@serverToRun			[varchar](4000),
			@databaseName			[sysname],
			@logName				[sysname],
			@strMessage				[nvarchar](4000),
			@ReturnValue			[int]

---------------------------------------------------------------------------------------------
--create temporary tables that will be used 
---------------------------------------------------------------------------------------------
IF object_id('tempdb..#DatabaseList') IS NOT NULL 
	DROP TABLE #DatabaseList

CREATE TABLE #DatabaseList(
								[dbname] [sysname]
							)

---------------------------------------------------------------------------------------------
IF object_id('tempdb..#databaseFiles') IS NOT NULL 
	DROP TABLE #databaseFiles

CREATE TABLE #databaseFiles(
								[name] [varchar](4000)
							)

---------------------------------------------------------------------------------------------
SET @ReturnValue	 = 1

---------------------------------------------------------------------------------------------
DECLARE @SQLMajorVersion [int]
SELECT @SQLMajorVersion = REPLACE(LEFT(ISNULL(CAST(SERVERPROPERTY('ProductVersion') AS [varchar](32)), ''), 2), '.', '') 
---------------------------------------------------------------------------------------------

EXEC [dbo].[usp_logPrintMessage] @customMessage = '<separator-line>', @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
SET @queryToRun= 'Shrinking database log files...' + ' [' + @DBName + ']'
EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0


---------------------------------------------------------------------------------------------
SET @serverToRun='[' + @SQLServerName + '].[master].[dbo].[sp_executesql]'
---------------------------------------------------------------------------------------------

--get database list that will be analyzed
SET @queryToRun = N''

SET @queryToRun = @queryToRun + N'SELECT DISTINCT [name] FROM master..sysdatabases WHERE [name] LIKE ''' + CASE WHEN @DBName IS NULL THEN '%' ELSE @DBName END + ''''

SET @queryToRun = [dbo].[ufn_formatSQLQueryForLinkedServer](@SQLServerName, @queryToRun)
IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

DELETE FROM #DatabaseList
INSERT	INTO #DatabaseList([dbname])
		EXEC (@queryToRun)


DECLARE crsDatabases CURSOR LOCAL FAST_FORWARD FOR	SELECT	[dbname] 
													FROM	#DatabaseList
OPEN crsDatabases
FETCH NEXT FROM crsDatabases INTO @databaseName
WHILE @@FETCH_STATUS=0
	begin
		DELETE FROM #databaseFiles

		SET @queryToRun = N'SELECT [name] FROM [' + @databaseName + ']..sysfiles WHERE [status] & 0x40 = 0x40'
		SET @queryToRun = [dbo].[ufn_formatSQLQueryForLinkedServer](@SQLServerName, @queryToRun)
		IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
				
		INSERT	INTO #databaseFiles
				EXEC (@queryToRun)

		DECLARE crsLogFile CURSOR LOCAL FAST_FORWARD FOR SELECT LTRIM(RTRIM([name])) FROM #databaseFiles
		OPEN crsLogFile
		FETCH NEXT FROM crsLogFile INTO @logName
		WHILE @@FETCH_STATUS=0
			begin
				SET @queryToRun = N'USE [' + @databaseName + ']; DBCC SHRINKFILE([' + @logName + ']) WITH NO_INFOMSGS'
				IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
						
				EXEC @serverToRun @queryToRun 
				FETCH NEXT FROM crsLogFile INTO @logName
			END
		CLOSE crsLogFile
		DEALLOCATE crsLogFile

		FETCH NEXT FROM crsDatabases INTO @databaseName
	end
CLOSE crsDatabases
DEALLOCATE crsDatabases

RETURN @ReturnValue
GO
