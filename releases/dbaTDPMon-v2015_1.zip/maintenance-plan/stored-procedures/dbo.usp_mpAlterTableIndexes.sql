-- ============================================================================
-- Author     : Andrei STEFAN
-- Create date: 08.01.2010
-- Module     : Database Maintenance Scripts
-- ============================================================================

-----------------------------------------------------------------------------------------
-- Input Parameters:
--		@SQLServerName	- name of SQL Server instance to analyze
--		@DBName			- database to be analyzed
--		@TableSchema	- schema that current table belongs to
--		@TableName		- specify table name to be analyzed.
--		@IndexName		- name of the index to be analyzed
--		@IndexID		- id of the index to be analyzed. to may specify either index name or id. 
--						  if you specify both, index name will be taken into consideration
--		@PartitionNumber- index partition number. default value = 1 (index with no partitions)
--		@flgAction:		 1	- Rebuild index (default)
--						 2  - Reorganize indexes
--						 4	- Disable index
--		@flgOptions		 1  - Compact large objects (LOB) when reorganize  (default)
--						 2  - Rebuild index by create with drop existing on
--						 4  - Rebuild all non-clustered indexes when rebuild clustered indexes (default)
--						 8  - Disable non-clustered index before rebuild (save space) (default) (won't apply when 4096 is applicable)
--						16  - Disable all foreign key constraints that reffered current table before rebuilding clustered indexes (default)
--						64  - When enabling foreign key constraints, do no check values. Default behaviour is to enabled foreign key constraint with check option
--					  2048  - send email when a error occurs (default)
--					  4096  - rebuild/reorganize indexes using ONLINE=ON, if applicable (default)
--		@DebugMode:		 1 - print dynamic SQL statements 
--						 0 - no statements will be displayed (default)
-----------------------------------------------------------------------------------------
-- Return : 
-- 1 : Succes  -1 : Fail 
-----------------------------------------------------------------------------------------
RAISERROR('Create procedure: [dbo].[usp_mpAlterTableIndexes]', 10, 1) WITH NOWAIT
GO
IF  EXISTS (
	    SELECT * 
	      FROM sys.objects 
	     WHERE object_id = OBJECT_ID(N'[dbo].[usp_mpAlterTableIndexes]') 
	       AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_mpAlterTableIndexes]
GO

-----------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_mpAlterTableIndexes]
		@SQLServerName		[sysname],
		@DBName				[sysname],
		@TableSchema		[sysname] = '%',
		@TableName			[sysname] = '%',
		@IndexName			[sysname] = '%',
		@IndexID			[int],
		@PartitionNumber	[int] = 1,
		@flgAction			[tinyint] = 1,
		@flgOptions			[smallint] = 6173,
		@executionLevel		[tinyint] = 0,
		@DebugMode			[bit] = 0
AS

DECLARE		@tmpSQL    				[nvarchar](max),
			@tmpServer				[varchar](256),
			@sqlIndexCreate			[nvarchar](max),
			@sqlScriptOnline		[nvarchar](512),
			@strMessage				[nvarchar](max),
			@eventName				[nvarchar](256),
			@crtTableSchema 		[sysname],
			@crtTableName 			[sysname],
			@crtIndexID				[int],
			@crtIndexName			[sysname],			
			@crtIndexType			[tinyint],
			@crtIndexAllowPageLocks	[bit],
			@flgInheritOptions		[int],
			@tmpIndexName			[sysname],
			@ReturnValue			[int], 
			@nestExecutionLevel		[tinyint]

DECLARE   @flgRaiseErrorAndStop [bit]
		, @errorString			[nvarchar](max)

DECLARE @NonClusteredIndexes TABLE	(
										[IndexName]	[sysname]	NULL
									)

SET NOCOUNT ON

DECLARE @tmpTableToAlterIndexes TABLE
			(
				[index_id]			[int]		NULL
			  , [index_name]		[sysname]	NULL
			  , [index_type]		[tinyint]	NULL
			  , [allow_page_locks]	[bit]		NULL
			)


-- { sql_statement | statement_block }
BEGIN TRY
		SET @ReturnValue	 = 1

		---------------------------------------------------------------------------------------------
		SET @tmpServer		='[' + @SQLServerName + '].[' + @DBName + '].[dbo].sp_executesql'
		---------------------------------------------------------------------------------------------

		--get tables list	
		IF object_id('tempdb..#tmpTableList') IS NOT NULL DROP TABLE #tmpTableList
		CREATE TABLE #tmpTableList 
				(
					[table_schema] [sysname],
					[table_name] [sysname]
				)

		SET @tmpSQL = N'SELECT TABLE_SCHEMA, TABLE_NAME 
						FROM [' + @DBName + '].INFORMATION_SCHEMA.TABLES 
						WHERE	TABLE_TYPE = ''BASE TABLE'' 
								AND TABLE_NAME LIKE ''' + @TableName + ''' 
								AND TABLE_SCHEMA LIKE ''' + @TableSchema + ''''
		SET @tmpSQL = [dbo].[ufn_formatSQLQueryForLinkedServer](@SQLServerName, @tmpSQL)
		IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @tmpSQL, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

		INSERT	INTO #tmpTableList ([table_schema], [table_name])
				EXEC (@tmpSQL)

		---------------------------------------------------------------------------------------------
		IF EXISTS(SELECT 1 FROM #tmpTableList)
			begin
				DECLARE crsTableList CURSOR LOCAL FAST_FORWARD FOR	SELECT [table_schema], [table_name]
																	FROM #tmpTableList
																	ORDER BY [table_schema], [table_name]
				OPEN crsTableList
				FETCH NEXT FROM crsTableList INTO @crtTableSchema, @crtTableName
				WHILE @@FETCH_STATUS=0
					begin
						SET @strMessage=N'Alter indexes ON [' + @crtTableSchema + '].[' + @crtTableName + '] : ' + 
									CASE @flgAction WHEN 1 THEN 'REBUILD'
													WHEN 2 THEN 'REORGANIZE'
													WHEN 4 THEN 'DISABLE'
													ELSE 'N/A'
									END
						EXEC [dbo].[usp_logPrintMessage] @customMessage = @strMessage, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

						--if current action is to disable/reorganize indexes, will get only enabled indexes
						--if current action is to rebuild, will get both enabled/disabled indexes
						SET @tmpSQL = N''
						SET @tmpSQL = @tmpSQL + N'SELECT  si.[index_id]
														, si.[name]
														, si.[type]
														, si.[allow_page_locks]
													FROM [' + @DBName + '].[sys].[indexes]				si
													INNER JOIN [' + @DBName + '].[sys].[objects]		so  ON so.[object_id] = si.[object_id]
													INNER JOIN [' + @DBName + '].[sys].[schemas]		sch ON sch.[schema_id] = so.[schema_id]
													WHERE	so.[name] = ''' + @crtTableName + '''
															AND sch.[name] = ''' + @crtTableSchema + '''
															AND so.[is_ms_shipped] = 0' + 
															CASE	WHEN @IndexName IS NOT NULL 
																	THEN ' AND si.[name] LIKE ''' + @IndexName + ''''
																	ELSE CASE WHEN @IndexID  IS NOT NULL 
																			  THEN ' AND si.[index_id] = ' + CAST(@IndexID AS [nvarchar])
																			  ELSE ''
																		 END
															END + '
															AND si.[is_disabled] IN ( ' + CASE WHEN @flgAction IN (2, 4) THEN '0' ELSE '0,1' END + ')'

						SET @tmpSQL = [dbo].[ufn_formatSQLQueryForLinkedServer](@SQLServerName, @tmpSQL)
						IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @tmpSQL, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

						DELETE FROM @tmpTableToAlterIndexes
						INSERT	INTO @tmpTableToAlterIndexes([index_id], [index_name], [index_type], [allow_page_locks])
								EXEC (@tmpSQL)

						FETCH NEXT FROM crsTableList INTO @crtTableSchema, @crtTableName
					end
				CLOSE crsTableList
				DEALLOCATE crsTableList



				DECLARE crsTableToAlterIndexes CURSOR	LOCAL FAST_FORWARD FOR	SELECT DISTINCT [index_id], [index_name], [index_type], [allow_page_locks]
																				FROM @tmpTableToAlterIndexes
																				ORDER BY [index_id], [index_name]						
				OPEN crsTableToAlterIndexes
				FETCH NEXT FROM crsTableToAlterIndexes INTO @crtIndexID, @crtIndexName, @crtIndexType, @crtIndexAllowPageLocks
				WHILE @@FETCH_STATUS=0
					begin
						SET @strMessage= '[' + @crtIndexName + ']'
						EXEC [dbo].[usp_logPrintMessage] @customMessage = @strMessage, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 2, @stopExecution=0

						SET @sqlScriptOnline=N''
						---------------------------------------------------------------------------------------------
						-- 1  - Rebuild indexes
						---------------------------------------------------------------------------------------------
						IF @flgAction = 1
							begin
								-- check for online operation mode	
								IF @flgOptions & 4096 = 4096
									begin
										SET @nestExecutionLevel = @executionLevel + 3
										EXEC [dbo].[usp_mpCheckIndexOnlineOperation]	@sqlServerName		= @SQLServerName,
																						@dbName				= @DBName,
																						@tableSchema		= @crtTableSchema,
																						@tableName			= @crtTableName,
																						@indexName			= @crtIndexName,
																						@indexID			= @crtIndexID,
																						@partitionNumber	= @PartitionNumber,
																						@sqlScriptOnline	= @sqlScriptOnline OUT,
																						@flgOptions			= @flgOptions,
																						@executionLevel		= @nestExecutionLevel,
																						@debugMode			= @DebugMode
									end

								--clustered index options
								IF @crtIndexType = 1 
									begin
										-- 16  - Disable all foreign key constraints that reffered current table before rebuilding clustered indexes (default)
										IF @flgOptions & 16 = 16
											begin
												SET @flgInheritOptions = 1								-- Use tables that have foreign key constraints that reffers current table (default)
												SET @nestExecutionLevel = @executionLevel + 3
												EXEC [dbo].[usp_mpAlterTableForeignKeys]	  @SQLServerName	= @SQLServerName
																							, @DBName			= @DBName
																							, @TableSchema		= @crtTableSchema
																							, @TableName		= @crtTableName
																							, @ConstraintName	= '%'
																							, @flgAction		= 0		-- Disable Constraints
																							, @flgOptions		= @flgInheritOptions
																							, @executionLevel	= @nestExecutionLevel
																							, @DebugMode		= @DebugMode
											end

										--4  - Rebuild all non-clustered indexes when rebuild clustered indexes (default)
										IF @flgOptions & 4 = 4
											begin
												--get all enabled non-clustered indexes for current table
												SET @tmpSQL = N''
												SET @tmpSQL = @tmpSQL + N'SELECT  idx.[name]
																			FROM [' + @DBName + '].[sys].[indexes]				idx
																			INNER JOIN [' + @DBName + '].[sys].[objects]		obj ON  idx.[object_id] = obj.[object_id]
																			INNER JOIN [' + @DBName + '].[sys].[schemas]		sch ON sch.[schema_id] = obj.[schema_id]
																			WHERE	obj.[name] = ''' + @crtTableName + '''
																					AND sch.[name] = ''' + @crtTableSchema + ''' 
																					AND idx.[type] = 2
																					AND idx.[is_disabled] = 0'
												SET @tmpSQL = [dbo].[ufn_formatSQLQueryForLinkedServer](@SQLServerName, @tmpSQL)
												IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @tmpSQL, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

												INSERT INTO @NonClusteredIndexes ([IndexName])
													EXEC (@tmpSQL)
											end

										--8  - Disable non-clustered index before rebuild (save space) (default)
										--won't disable the index when performing online rebuild
										IF @flgOptions & 8 = 8 AND NOT ((@flgOptions & 4096 = 4096) AND (@sqlScriptOnline = N'ONLINE = ON'))
											begin
												--foreign key constraints are alredy disabled
												SET @flgInheritOptions = @flgOptions
												IF @flgOptions & 16 = 16
													SET @flgInheritOptions = @flgInheritOptions - 16

												DECLARE crsNonClusteredIndexes	CURSOR LOCAL FAST_FORWARD FOR
																				SELECT [IndexName]
																				FROM @NonClusteredIndexes
												OPEN crsNonClusteredIndexes
												FETCH NEXT FROM crsNonClusteredIndexes INTO @tmpIndexName
												WHILE @@FETCH_STATUS=0
													begin
														SET @nestExecutionLevel = @executionLevel + 2
														EXEC [dbo].[usp_mpAlterTableIndexes]	  @SQLServerName	= @SQLServerName
																								, @DBName			= @DBName
																								, @TableSchema		= @crtTableSchema
																								, @TableName		= @crtTableName
																								, @IndexName		= @tmpIndexName
																								, @IndexID			= NULL
																								, @PartitionNumber	= DEFAULT
																								, @flgAction		= 4				--disable
																								, @flgOptions		= @flgInheritOptions
																								, @executionLevel	= @nestExecutionLevel
																								, @DebugMode		= @DebugMode										

														FETCH NEXT FROM crsNonClusteredIndexes INTO @tmpIndexName
													end
												CLOSE crsNonClusteredIndexes
												DEALLOCATE crsNonClusteredIndexes
											end
									end
								ELSE
									--8  - Disable non-clustered index before rebuild (save space) (default)
									--won't disable the index when performing online rebuild
									IF @flgOptions & 8 = 8 AND NOT ((@flgOptions & 4096 = 4096) AND (@sqlScriptOnline = N'ONLINE = ON'))
										begin
											--foreign key constraints are alredy disabled
											SET @flgInheritOptions = @flgOptions
											IF @flgOptions & 16 = 16
												SET @flgInheritOptions = @flgInheritOptions - 16

											SET @nestExecutionLevel = @executionLevel + 2
											EXEC [dbo].[usp_mpAlterTableIndexes]	  @SQLServerName	= @SQLServerName
																					, @DBName			= @DBName
																					, @TableSchema		= @crtTableSchema
																					, @TableName		= @crtTableName
																					, @IndexName		= @crtIndexName
																					, @IndexID			= NULL
																					, @PartitionNumber	= @PartitionNumber
																					, @flgAction		= 4				--disable
																					, @flgOptions		= @flgInheritOptions
																					, @executionLevel	= @nestExecutionLevel
																					, @DebugMode		= @DebugMode										
										end

			
								--generate rebuild index script
								SET @tmpSQL = N''

								--2  - Rebuild index by create with drop existing on (default)			
								IF @flgOptions & 2 = 2					
									begin
										--rebuild only current index
										SET @flgInheritOptions = 3
										IF @flgOptions & 4096 = 4096
											SET @flgInheritOptions = @flgInheritOptions + 4096
										
										SET @nestExecutionLevel = @executionLevel + 2
										EXEC [dbo].[usp_mpGetIndexCreationScript]	  @SQLServerName	= @SQLServerName
																					, @DBName			= @DBName
																					, @TableSchema		= @crtTableSchema
																					, @TableName		= @crtTableName
																					, @IndexName		= @crtIndexName
																					, @IndexID			= NULL
																					, @flgOptions		= @flgInheritOptions
																					, @sqlIndexCreate	= @sqlIndexCreate OUT
																					, @executionLevel	= @nestExecutionLevel
																					, @DebugMode		= @DebugMode
										SET @tmpSQL = @sqlIndexCreate
									end
								ELSE
									begin
										SET @tmpSQL = @tmpSQL + N'SET QUOTED_IDENTIFIER ON; ALTER INDEX [' + @crtIndexName + '] ON [' + @crtTableSchema + '].[' + @crtTableName + '] REBUILD'
					
										--rebuild options
										SET @tmpSQL = @tmpSQL + N' WITH (SORT_IN_TEMPDB = ON, MAXDOP = 1' + N', ' + @sqlScriptOnline + N')'

										IF @PartitionNumber>1
											SET @tmpSQL = @tmpSQL + N' PARTITION ' + CAST(@PartitionNumber AS [nvarchar])
									end

								IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @tmpSQL, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

								BEGIN TRY
									SET @strMessage= 'Rebuilding index [' + @crtIndexName + ']'
									EXEC [dbo].[usp_logPrintMessage] @customMessage = @strMessage, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 3, @stopExecution=0
						
									EXEC @tmpServer @tmpSQL

									EXEC [dbo].[usp_mpMarkInternalAction]	@actionName		= N'index-made-disable',
																			@flgOperation	= 2,
																			@value1			= @DBName,
																			@value2			= @crtTableSchema,
																			@value3			= @crtTableName,
																			@value4			= @crtIndexName
								END TRY

								BEGIN CATCH
									SET @errorString = ERROR_MESSAGE()
									SET @flgRaiseErrorAndStop = 0
									SET @eventName = @DBName + ': Database Maintenance Error - ' + 'Rebuilding Index [' + @crtIndexName + ']' + ' on [' + @crtTableSchema + '].[' + @crtTableName + ']'
									SET @strMessage = ''

									EXEC [dbo].[usp_logMessageFormatAndRaise]	@sqlServerName			= @SQLServerName,
																				@module					= 'dbo.usp_mpAlterTableIndexes',
																				@eventName				= @eventName, 
																				@customMessage			= @strMessage, 
																				@errorString			= @errorString,
																				@queryExecuted			= @tmpSQL,
																				@flgRaiseErrorAndStop	= @flgRaiseErrorAndStop
								END CATCH

								--rebuild non-clustered indexes
								--clustered index options
								IF @crtIndexType = 1 
									begin
										--4  - Rebuild all non-clustered indexes when rebuild clustered indexes (default)
										--will rebuild only indexes disabled by this tool
										IF (@flgOptions & 4 = 4)
											begin
												--foreign key constraints are alredy disabled
												SET @flgInheritOptions = @flgOptions
												IF @flgOptions & 16 = 16
													SET @flgInheritOptions = @flgInheritOptions - 16
												--non-clustered indexes are already disabled
												IF @flgOptions & 8 = 8
													SET @flgInheritOptions = @flgInheritOptions - 8
													
												DECLARE crsNonClusteredIndexes	CURSOR LOCAL FAST_FORWARD FOR
																				SELECT DISTINCT nci.[IndexName]
																				FROM @NonClusteredIndexes nci
																				INNER JOIN [dbo].[statsMaintenancePlanInternals] smpi ON	smpi.[name]=N'index-made-disable'
																																		AND smpi.[value1]=@DBName
																																		AND smpi.[value2]=@crtTableSchema
																																		AND smpi.[value3]=@crtTableName
																																		AND smpi.[value4]=nci.[IndexName]
												OPEN crsNonClusteredIndexes
												FETCH NEXT FROM crsNonClusteredIndexes INTO @tmpIndexName
												WHILE @@FETCH_STATUS=0
													begin
														SET @nestExecutionLevel = @executionLevel + 2
														EXEC [dbo].[usp_mpAlterTableIndexes]	  @SQLServerName	= @SQLServerName
																								, @DBName			= @DBName
																								, @TableSchema		= @crtTableSchema
																								, @TableName		= @crtTableName
																								, @IndexName		= @tmpIndexName
																								, @IndexID			= NULL
																								, @PartitionNumber	= DEFAULT
																								, @flgAction		= 1		--rebuild
																								, @flgOptions		= @flgInheritOptions
																								, @executionLevel	= @nestExecutionLevel
																								, @DebugMode		= @DebugMode										

														FETCH NEXT FROM crsNonClusteredIndexes INTO @tmpIndexName
													end
												CLOSE crsNonClusteredIndexes
												DEALLOCATE crsNonClusteredIndexes
											end

										-- 16  - Disable all foreign key constraints that reffered current table before rebuilding clustered indexes (default)
										-- must enable previous disabled constraints
										IF @flgOptions & 16 = 16
											begin
												SET @flgInheritOptions = 1								-- Use tables that have foreign key constraints that reffers current table (default)

												--64  - When enabling foreign key constraints, do no check values. Default behaviour is to enabled foreign key constraint with check option
												IF @flgOptions & 64 = 64
													SET @flgInheritOptions = @flgInheritOptions + 4		-- Enable constraints with NOCHECK. Default is to enable constraints using CHECK option

												SET @nestExecutionLevel = @executionLevel + 3
												EXEC [dbo].[usp_mpAlterTableForeignKeys]	  @SQLServerName	= @SQLServerName
																							, @DBName			= @DBName
																							, @TableSchema		= @crtTableSchema
																							, @TableName		= @crtTableName
																							, @ConstraintName	= '%'
																							, @flgAction		= 1		-- Enable Constraints
																							, @flgOptions		= @flgInheritOptions
																							, @executionLevel	= @nestExecutionLevel
																							, @DebugMode		= @DebugMode
											end
									end					
							end

						---------------------------------------------------------------------------------------------
						-- 2  - Reorganize indexes
						---------------------------------------------------------------------------------------------
						-- avoid messages like:	The index [...] on table [..] cannot be reorganized because page level locking is disabled.		
						IF @flgAction = 2 
							IF @crtIndexAllowPageLocks=1
								begin
									SET @tmpSQL = N''
									SET @tmpSQL = @tmpSQL + N'ALTER INDEX [' + @crtIndexName + '] ON [' + @crtTableSchema + '].[' + @crtTableName + '] REORGANIZE'
				
									--  1  - Compact large objects (LOB) (default)
									IF @flgOptions & 1 = 1
										SET @tmpSQL = @tmpSQL + N' WITH (LOB_COMPACTION = ON) '
									ELSE
										SET @tmpSQL = @tmpSQL + N' WITH (LOB_COMPACTION = OFF) '
				
									IF @PartitionNumber>1
										SET @tmpSQL = @tmpSQL + N' PARTITION ' + CAST(@PartitionNumber AS [nvarchar])
									IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @tmpSQL, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

									BEGIN TRY
										EXEC @tmpServer @tmpSQL
									END TRY

									BEGIN CATCH
										SET @errorString = ERROR_MESSAGE()
										SET @flgRaiseErrorAndStop = 0
										SET @eventName = @DBName + ': Database Maintenance Error - ' + 'Reorganize Index [' + @crtIndexName + ']' + ' on [' + @crtTableSchema + '].[' + @crtTableName + ']'
										SET @strMessage = ''

										EXEC [dbo].[usp_logMessageFormatAndRaise]	@sqlServerName			= @SQLServerName,
																					@module					= 'dbo.usp_mpAlterTableIndexes',
																					@eventName				= @eventName, 
																					@customMessage			= @strMessage, 
																					@errorString			= @errorString,
																					@queryExecuted			= @tmpSQL,
																					@flgRaiseErrorAndStop	= @flgRaiseErrorAndStop
									END CATCH
								end
							ELSE
								begin
									SET @strMessage=N'--	index cannot be REORGANIZE because ALLOW_PAGE_LOCKS is set to OFF. Skipping...'
									EXEC [dbo].[usp_logPrintMessage] @customMessage = @strMessage, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 3, @stopExecution=0
								end

						---------------------------------------------------------------------------------------------
						-- 4  - Disable indexes 
						---------------------------------------------------------------------------------------------
						IF @flgAction = 4
							begin
								SET @tmpSQL = N''
								SET @tmpSQL = @tmpSQL + N'ALTER INDEX [' + @crtIndexName + '] ON [' + @crtTableSchema + '].[' + @crtTableName + '] DISABLE'
				
								IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @tmpSQL, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

								BEGIN TRY
									EXEC @tmpServer @tmpSQL

									/* 4 disable index -> insert action 1 */
									EXEC [dbo].[usp_mpMarkInternalAction]	@actionName		= N'index-made-disable',
																			@flgOperation	= 1,
																			@value1			= @DBName,
																			@value2			= @crtTableSchema,
																			@value3			= @crtTableName,
																			@value4			= @crtIndexName
								END TRY

								BEGIN CATCH
									SET @errorString = ERROR_MESSAGE()
									SET @flgRaiseErrorAndStop = 0
									SET @eventName = @DBName + ': Database Maintenance Error - ' + 'Disable Index [' + @crtIndexName + ']' + ' on [' + @crtTableSchema + '].[' + @crtTableName + ']'
									SET @strMessage = ''

									EXEC [dbo].[usp_logMessageFormatAndRaise]	@sqlServerName			= @SQLServerName,
																				@module					= 'dbo.usp_mpAlterTableIndexes',
																				@eventName				= @eventName, 
																				@customMessage			= @strMessage, 
																				@errorString			= @errorString,
																				@queryExecuted			= @tmpSQL,
																				@flgRaiseErrorAndStop	= @flgRaiseErrorAndStop
								END CATCH
							end

						FETCH NEXT FROM crsTableToAlterIndexes INTO @crtIndexID, @crtIndexName, @crtIndexType, @crtIndexAllowPageLocks
					end
				CLOSE crsTableToAlterIndexes
				DEALLOCATE crsTableToAlterIndexes
			end
END TRY

BEGIN CATCH
DECLARE 
        @ErrorMessage    NVARCHAR(4000),
        @ErrorNumber     INT,
        @ErrorSeverity   INT,
        @ErrorState      INT,
        @ErrorLine       INT,
        @ErrorProcedure  NVARCHAR(200);
    -- Assign variables to error-handling functions that 
    -- capture information for RAISERROR.
	SET @ReturnValue = -1

    SELECT 
        @ErrorNumber = ERROR_NUMBER(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = CASE WHEN ERROR_STATE() BETWEEN 1 AND 127 THEN ERROR_STATE() ELSE 1 END ,
        @ErrorLine = ERROR_LINE(),
        @ErrorProcedure = ISNULL(ERROR_PROCEDURE(), '-');
	-- Building the message string that will contain original
    -- error information.
    SELECT @ErrorMessage = 
        N'Error %d, Level %d, State %d, Procedure %s, Line %d, ' + 
            'Message: '+ ERROR_MESSAGE();
    -- Raise an error: msg_str parameter of RAISERROR will contain
    -- the original error information.
    RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        @ErrorState,               
        @ErrorNumber,    -- parameter: original error number.
        @ErrorSeverity,  -- parameter: original error severity.
        @ErrorState,     -- parameter: original error state.
        @ErrorProcedure, -- parameter: original error procedure name.
        @ErrorLine       -- parameter: original error line number.
        );

        -- Test XACT_STATE:
        -- If 1, the transaction is committable.
        -- If -1, the transaction is uncommittable and should 
        --     be rolled back.
        -- XACT_STATE = 0 means that there is no transaction and
        --     a COMMIT or ROLLBACK would generate an error.

    -- Test if the transaction is uncommittable.
    IF (XACT_STATE()) = -1
    BEGIN
        PRINT
            N'The transaction is in an uncommittable state.' +
            'Rolling back transaction.'
        ROLLBACK TRANSACTION 
   END;

END CATCH

RETURN @ReturnValue
GO
