USE [master]
GO

IF EXISTS(SELECT 1 FROM sysdatabases WHERE [name]='$(dbName)')
	begin
		PRINT 'Killing all open connections...'
		DECLARE @queryToRun [nvarchar](4000)

		SET @queryToRun=N''

		SELECT @queryToRun = @queryToRun + 'KILL ' + CAST([spid] AS [nvarchar]) + ';'
		FROM sysprocesses
		WHERE [dbid]=DB_ID('$(dbName)')

		EXEC (@queryToRun)

		DROP DATABASE [$(dbName)]
	end
GO	
