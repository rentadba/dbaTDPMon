SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

RAISERROR('Create procedure: [dbo].[usp_monGetReplicationPublicationLatency]', 10, 1) WITH NOWAIT
GO
IF  EXISTS (
	    SELECT * 
	      FROM sys.objects 
	     WHERE object_id = OBJECT_ID(N'[dbo].[usp_monGetReplicationPublicationLatency]') 
	       AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_monGetReplicationPublicationLatency]
GO

CREATE PROCEDURE [dbo].[usp_monGetReplicationPublicationLatency]
	  @publisherDB			[sysname]
	, @publicationName		[sysname]
	, @replicationDelay		[int] = 180
	, @iterations			[int] = 1
	, @iterationDelay		[varchar](10) = N'00:00:05'
/* WITH ENCRYPTION */
AS

-- ============================================================================
-- Copyright (c) 2004-2016 Dan Andrei STEFAN (danandrei.stefan@gmail.com)
-- ============================================================================
-- Author			 : Dan Andrei STEFAN
-- Create date		 : 12.01.2016
-- Module			 : Database Analysis & Performance Monitoring
-- ============================================================================
/*
	original code source:
	Name:       dba_replicationLatencyGet_sp
	Author:     Michelle F. Ufford
*/
SET NOCOUNT ON
DECLARE   @currentIteration [int]
		, @tokenID			[bigint]
		, @currentDateTime	[smalldatetime]
		, @tokenStartTime	[datetime]
		, @queryToRun		[nvarchar](4000)
		, @queryParam		[nvarchar](512)

IF NOT EXISTS(SELECT * FROM sysobjects WHERE [name]='replicationTokenResults' AND [type]='U')
	CREATE TABLE [dbo].[replicationTokenResults]
		(
			  [publisher_db]		[sysname] NULL
			, [publication]			[sysname] NULL
			, [iteration]			[int] NULL
			, [tracer_id]			[int] NULL
			, [distributor_latency]	[int] NULL
			, [subscriber]			[sysname] NULL
			, [subscriber_db]		[sysname] NULL
			, [subscriber_latency]	[int] NULL
			, [overall_latency]		[int] NULL
		)
ELSE
	DELETE FROM [dbo].[replicationTokenResults] WHERE [publication] = @publicationName AND [publisher_db] = @publisherDB

DECLARE @temptokenresult TABLE 
	(
		  [tracer_id]			[int] NULL
		, [distributor_latency] [int] NULL
		, [subscriber]			[sysname] NULL
		, [subscriber_db]		[sysname] NULL
		, [subscriber_latency]	[int] NULL
		, [overall_latency]		[int] NULL
	);

SET @currentIteration = 0
SET @currentDateTime  = GETDATE()

WHILE @currentIteration < @iterations
	begin
		/* Insert a new tracer token in the publication database */
		SET @queryToRun = N'EXECUTE [' + @publisherDB + N'].sys.sp_postTracerToken @publication = @publicationName, @tracer_token_id = @tokenID OUTPUT'
		SET @queryParam = N'@publicationName [sysname], @tokenID [bigint] OUTPUT'
					
		PRINT @queryToRun
		SET @tokenStartTime = GETDATE()
		EXEC sp_executesql @queryToRun, @queryParam , @publicationName = @publicationName
													, @tokenID = @tokenID OUTPUT

		WHILE GETDATE() <= DATEADD(ss, @replicationDelay, @tokenStartTime)
			begin
				/* Give a few seconds to allow the record to reach the subscriber */
				WAITFOR DELAY @iterationDelay

				SET @queryToRun = N'EXECUTE [' + @publisherDB + N'].sys.sp_helpTracerTokenHistory @publicationName, @tokenID' 
				PRINT @queryToRun

				/* Store our results in a temp table for retrieval later */
				INSERT	INTO @temptokenResult ([distributor_latency], [subscriber], [subscriber_db], [subscriber_latency], [overall_latency])
						EXEC sp_executesql @queryToRun, @queryParam , @publicationName = @publicationName
																	, @tokenID = @tokenID

				IF NOT EXISTS(SELECT * FROM @temptokenResult WHERE ISNULL([subscriber_latency], [overall_latency]) IS NULL)
					BREAK
				ELSE
					DELETE FROM @temptokenResult
			end

		INSERT	[dbo].[replicationTokenResults] ([publisher_db], [publication], [distributor_latency], [subscriber], [subscriber_db], [subscriber_latency], [overall_latency])
				SELECT    @publisherDB
						, @publicationName
						, distributor_latency
						, subscriber
						, subscriber_db
						, subscriber_latency
						, overall_latency
				FROM @temptokenResult

		/* Assign the iteration and token id to the results for easier investigation */
		UPDATE [dbo].[replicationTokenResults]
		SET   [iteration] = @currentIteration + 1
			, [tracer_id] = @tokenID
		WHERE [iteration] IS NULL;

		DELETE FROM @temptokenresult

		/* Wait for the specified time period before creating another token */
		WAITFOR DELAY @iterationDelay

		SET @currentIteration = @currentIteration + 1;
	end;

/* perform cleanup */
SET @queryToRun = N'EXECUTE [' + @publisherDB + N'].sys.sp_deleteTracerTokenHistory @publication = @publicationName, @cutoff_date = @currentDateTime'
SET @queryParam = N'@publicationName [sysname], @currentDateTime [datetime]'
PRINT @queryToRun

EXEC sp_executesql @queryToRun, @queryParam , @publicationName = @publicationName
											, @currentDateTime = @currentDateTime

SELECT * FROM [dbo].[replicationTokenResults]