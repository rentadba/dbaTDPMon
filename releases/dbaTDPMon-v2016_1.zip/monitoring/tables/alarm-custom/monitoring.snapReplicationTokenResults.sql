-- ============================================================================
-- Copyright (c) 2004-2015 Dan Andrei STEFAN (danandrei.stefan@gmail.com)
-- ============================================================================
-- Author			 : Dan Andrei STEFAN
-- Create date		 : 31.12.2015
-- Module			 : Database Analysis & Performance Monitoring
-- ============================================================================

-----------------------------------------------------------------------------------------------------
--
-----------------------------------------------------------------------------------------------------
RAISERROR('Create table: [monitoring].[snapReplicationTokenResults]', 10, 1) WITH NOWAIT
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[monitoring].[snapReplicationTokenResults]') AND type in (N'U'))
DROP TABLE [monitoring].[snapReplicationTokenResults]
GO
CREATE TABLE [monitoring].[snapReplicationTokenResults]
(
	[id]						[int] IDENTITY (1, 1) NOT NULL,
	[project_id]				[smallint]	NOT NULL,
	[publisher_server]			[sysname]	NULL,
	[publisher_db]				[sysname]	NULL,
	[publication]				[sysname]	NULL,
	[iteration]					[int]		NULL,
	[tracer_id]					[int]		NULL,
	[distributor_latency]		[int]		NULL,
	[subscriber_server]			[sysname]	NULL,
	[subscriber_db]				[sysname]	NULL,
	[subscriber_latency]		[int]		NULL,
	[overall_latency]			[int]		NULL,
	[event_date_utc]			[datetime]	NOT NULL CONSTRAINT [DF_monitoring_snapReplicationTokenResults_EventDateUTC] DEFAULT(GETUTCDATE()),
	CONSTRAINT [PK_snapReplicationTokenResults] PRIMARY KEY CLUSTERED 
	(
		[id]
	)  ON [FG_Statistics_Data],
	CONSTRAINT [FK_snapReplicationTokenResults_catalogProjects] FOREIGN KEY 
	(
		[project_id]
	) 
	REFERENCES [dbo].[catalogProjects] 
	(
		[id]
	),
) ON [FG_Statistics_Data]
GO

CREATE INDEX [IX_snapReplicationTokenResults_ProjectID] ON [monitoring].[snapReplicationTokenResults] ([project_id]) ON [FG_Statistics_Index]
GO
CREATE INDEX [IX_snapReplicationTokenResults_PublisherDB_SubcriptionDB] ON [monitoring].[snapReplicationTokenResults]([publisher_server], [publisher_db], [subscriber_server], [subscriber_db]) ON [FG_Statistics_Index]
GO
