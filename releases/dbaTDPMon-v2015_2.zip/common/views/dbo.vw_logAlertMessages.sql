-----------------------------------------------------------------------------------------------------
--
-----------------------------------------------------------------------------------------------------
RAISERROR('Create view : [dbo].[vw_logAlertMessages]', 10, 1) WITH NOWAIT
GO
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[vw_logAlertMessages]'))
DROP VIEW [dbo].[vw_logAlertMessages]
GO

CREATE VIEW [dbo].[vw_logAlertMessages]
AS

-- ============================================================================
-- Author			 : Andrei STEFAN (danandrei.stefan@gmail.com)
-- Create date		 : 08.01.2015
-- Module			 : Database Analysis & Performance Monitoring
-- ============================================================================

SELECT    am.[id]		AS [alert_message_id]
		, cin.[project_id] 
		, cin.[id]		AS [instance_id]
		, cin.[name]	AS [instance_name]
		, am.[event_date]
		, am.[module]
		, am.[parameters]
		, am.[event_name]
		, am.[message]
		, am.[send_email_to]
		, am.[event_type]
		, am.[event_type_desc]
		, am.[is_email_sent]
FROM [dbo].[logAlertMessages]		am
INNER JOIN [dbo].[catalogInstanceNames]		 cin	ON cin.[id] = am.[instance_id] AND cin.[project_id] = am.[project_id]
GO


