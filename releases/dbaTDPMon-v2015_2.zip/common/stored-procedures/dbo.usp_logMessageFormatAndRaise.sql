RAISERROR('Create procedure: [dbo].[usp_logMessageFormatAndRaise]', 10, 1) WITH NOWAIT
GO---
IF  EXISTS (
	    SELECT * 
	      FROM sys.objects 
	     WHERE object_id = OBJECT_ID(N'[dbo].[usp_logMessageFormatAndRaise]') 
	       AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_logMessageFormatAndRaise]
GO

CREATE PROCEDURE [dbo].[usp_logMessageFormatAndRaise]
		@sqlServerName			[sysname],
		@module					[varchar](32),
		@eventName				[nvarchar](256),
		@customMessage			[nvarchar](max),
		@errorString			[nvarchar](max),
		@queryExecuted			[nvarchar](max),
		@flgRaiseErrorAndStop	[bit]=0
AS

-- ============================================================================
-- Author			 : Andrei STEFAN (danandrei.stefan@gmail.com)
-- Create date		 : 05.02.2015
-- Module			 : Database Analysis & Performance Monitoring
-- ============================================================================

SET NOCOUNT ON

DECLARE @ReturnValue			[int],
		@strMessage				[nvarchar](max)
		
-- { sql_statement | statement_block }
BEGIN TRY
	SET @ReturnValue=0

	SET @strMessage = N''
	SET @strMessage = @strMessage + @customMessage
	SET @strMessage = @strMessage + N'<ul>'
	SET @strMessage = @strMessage + N'<li>' + @errorString + N'</li>'
	SET @strMessage = @strMessage + N'<li>' + @queryExecuted + '</li>'
	SET @strMessage = @strMessage + N'</ul>'
								
	EXEC [dbo].[usp_logAlertAndSendEmail]	@sqlServerName	= @sqlServerName,
											@module			= @module,
											@eventName		= @eventName,
											@alertMessage	= @strMessage,
											@eventType		= 1
	IF @flgRaiseErrorAndStop=1
		begin
			RAISERROR(@customMessage, 16, 1) WITH NOWAIT
		end
END TRY

BEGIN CATCH
DECLARE 
        @ErrorMessage    NVARCHAR(4000),
        @ErrorNumber     INT,
        @ErrorSeverity   INT,
        @ErrorState      INT,
        @ErrorLine       INT,
        @ErrorProcedure  NVARCHAR(200);
    -- Assign variables to error-handling functions that 
    -- capture information for RAISERROR.
    SELECT 
        @ErrorNumber = ERROR_NUMBER(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = CASE WHEN ERROR_STATE() BETWEEN 1 AND 127 THEN ERROR_STATE() ELSE 1 END ,
        @ErrorLine = ERROR_LINE(),
        @ErrorProcedure = ISNULL(ERROR_PROCEDURE(), '-');
	-- Building the message string that will contain original
    -- error information.
    SELECT @ErrorMessage = 
        N'Error %d, Level %d, State %d, Procedure %s, Line %d, ' + 
            'Message: '+ ERROR_MESSAGE();
    -- Raise an error: msg_str parameter of RAISERROR will contain
    -- the original error information.
    RAISERROR 
        (
        @ErrorMessage, 
        @ErrorSeverity, 
        @ErrorState,               
        @ErrorNumber,    -- parameter: original error number.
        @ErrorSeverity,  -- parameter: original error severity.
        @ErrorState,     -- parameter: original error state.
        @ErrorProcedure, -- parameter: original error procedure name.
        @ErrorLine       -- parameter: original error line number.
        );

        -- Test XACT_STATE:
        -- If 1, the transaction is committable.
        -- If -1, the transaction is uncommittable and should 
        --     be rolled back.
        -- XACT_STATE = 0 means that there is no transaction and
        --     a COMMIT or ROLLBACK would generate an error.

    -- Test if the transaction is uncommittable.
    IF (XACT_STATE()) = -1
    BEGIN
        PRINT
            N'The transaction is in an uncommittable state.' +
            'Rolling back transaction.'
        ROLLBACK TRANSACTION 
   END;

END CATCH

RETURN @ReturnValue
GO
