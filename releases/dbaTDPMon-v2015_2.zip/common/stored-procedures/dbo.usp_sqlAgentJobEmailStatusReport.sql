RAISERROR('Create procedure: [dbo].[usp_sqlAgentJobEmailStatusReport]', 10, 1) WITH NOWAIT
GO---
IF  EXISTS (
	    SELECT * 
	      FROM sys.objects 
	     WHERE object_id = OBJECT_ID(N'[dbo].[usp_sqlAgentJobEmailStatusReport]') 
	       AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_sqlAgentJobEmailStatusReport]
GO

CREATE PROCEDURE [dbo].[usp_sqlAgentJobEmailStatusReport]
		@jobName				[nvarchar](256),
		@logFileLocation		[nvarchar](512),
		@module					[varchar](32),
		@sendLogAsAttachment	[bit]=1
AS

SET NOCOUNT ON

-- ============================================================================
-- Author			 : Andrei STEFAN (danandrei.stefan@gmail.com)
-- Create date		 : 17.03.2015
-- Module			 : Database Analysis & Performance Monitoring
-- ============================================================================

DECLARE @HTMLTable		[nvarchar](max),
		@HTMLBody		[nvarchar](max),
		@eventName		[nvarchar](256),
		@jobID			[uniqueidentifier]


--get job id
SELECT	@jobID = [job_id] 
FROM	[msdb].[dbo].[sysjobs] 
WHERE	[name]=@jobName 

SET @eventName  = @jobName + ' completed '

SET @HTMLBody = '<br>'
SET @HTMLTable =@HTMLBody + COALESCE(
				N'<H1>' + @jobName + '</H1>' +
					N'<TABLE BORDER="1">' +
					N'<TR>' +
						N'<TH>Step ID</TH>
							<TH>Step Name</TH>
							<TH>Run Status</TH>
							<TH>Run Date</TH>
							<TH>Run Time</TH>
							<TH>Run Duration</TH>' +
						CAST ( ( 
								SELECT	TD = [step_id], '',
										TD = [step_name], '',
										TD = [run_status], '',
										TD = [run_date], '',
										TD = [run_time], '',
										TD = [run_duration], ''
								FROM (
										SELECT	  [step_id]
												, [step_name]
												, [run_status]
												, SUBSTRING([run_date], 1, 4) + '-' + SUBSTRING([run_date], 5 ,2) + '-' + SUBSTRING([run_date], 7 ,2) AS [run_date]
												, SUBSTRING([run_time], 1,2) + ':' + SUBSTRING([run_time], 3,2) + ':' + SUBSTRING([run_time], 5,2) AS [run_time]
												, SUBSTRING([run_duration], 1,2) + 'h ' + SUBSTRING([run_duration], 3,2) + 'm ' + SUBSTRING([run_duration], 5,2) + 's ' AS [run_duration]
										FROM (		
												SELECT	  h.[step_id]
														, h.[step_name]
														, CASE h.[run_status]	WHEN '0' THEN 'Failed'
																				WHEN '1' THEN 'Succeded'	
																				WHEN '2' THEN 'Retry'
																				WHEN '3' THEN 'Canceled'
																				WHEN '4' THEN 'In progress'
																				ELSE 'Unknown'
															END [run_status]
														, CAST(h.[run_date] AS varchar) AS [run_date]
														, REPLICATE('0', 6-LEN(CAST(h.[run_time] AS varchar))) + CAST(h.[run_time] AS varchar) AS [run_time]
														, REPLICATE('0', 6-LEN(CAST(h.[run_duration] AS varchar))) + CAST(h.[run_duration] AS varchar) AS [run_duration]
														, h.[instance_id]
												FROM [msdb].[dbo].[sysjobs] j 
												RIGHT JOIN [msdb].[dbo].[sysjobhistory] h	 ON j.[job_id] = h.[job_id] 
												WHERE j.[job_id] = @jobID
													AND	h.[instance_id]>ISNULL((SELECT MAX(h.[instance_id])
																				FROM [msdb].[dbo].[sysjobs] j 
																				RIGHT JOIN [msdb].[dbo].[sysjobhistory] h ON j.[job_id] = h.[job_id] 
																				WHERE	j.[job_id] = @jobID
																						AND h.[step_name] ='(Job outcome)'
																				),0)	
											)A
										)x										
								FOR XML PATH('TR'), TYPE 
					) AS NVARCHAR(MAX) ) +
					N'</TABLE>', '') ;

-- go out in style
SET @HTMLTable = N'
				<style>
					body {
						/*background-color: #F0F8FF;*/
						font-family: Arial, Tahoma;
					}
					h1 {
						font-size: 20px;
						font-weight: bold;
					}
					table {
						border-color: #ccc;
						border-collapse: collapse;
					}
					th {
						font-size: 12px;
						font-weight: bold;
						font-color: #000000;
						border-spacing: 2px;
						border-style: solid;
						border-width: 1px;
						border-color: #ccc;
						background-color: #00AEEF;
						padding: 4px;
					}
					td {
						font-size: 12px;
						border-spacing: 2px;
						border-style: solid;
						border-width: 1px;
						border-color: #ccc;
						background-color: #EDF8FE;
						padding: 4px;
					}
				</style>' + @HTMLTable

IF @sendLogAsAttachment=0
	SET @logFileLocation = NULL

EXEC [dbo].[usp_logAlertAndSendEmail] @projectCode	= NULL,
									@sqlServerName	= @@SERVERNAME,
									@module			= @module,
									@eventName		= @eventName,
									@parameters		= @logFileLocation,
									@alertMessage	= @HTMLTable,
									@recipientsList	= NULL,
									@eventType		= 2


--if one of the job steps failed, will fail the job
DECLARE @failedSteps [int]

SELECT @failedSteps = COUNT(*)
FROM [msdb].[dbo].[sysjobs] j 
RIGHT JOIN [msdb].[dbo].[sysjobhistory] h	 ON j.[job_id] = h.[job_id] 
WHERE j.[job_id] = @jobID
	AND	h.[instance_id]>ISNULL( (SELECT MAX(h.[instance_id])
								 FROM	[msdb].[dbo].[sysjobs] j 
								 RIGHT JOIN [msdb].[dbo].[sysjobhistory] h ON j.[job_id] = h.[job_id] 
								 WHERE	j.[job_id] = @jobID
										AND h.[step_name] ='(Job outcome)'
								),0)
	AND h.[run_status]=0 /* Failed */

IF @failedSteps <> 0
	begin
		SET @eventName = 'Job execution failed. See individual steps status.'
		EXEC [dbo].[usp_logPrintMessage] @customMessage = @eventName, @raiseErrorAsPrint = 1, @messagRootLevel = 0, @messageTreelevel = 0, @stopExecution=1
	end

GO
