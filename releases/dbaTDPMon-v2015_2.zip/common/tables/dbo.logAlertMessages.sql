-- ============================================================================
-- Author			 : Andrei STEFAN (danandrei.stefan@gmail.com)
-- Create date		 : 08.01.2015
-- Module			 : Database Analysis & Performance Monitoring
-- ============================================================================

-----------------------------------------------------------------------------------------------------
RAISERROR('Create table: [dbo].[logAlertMessages]', 10, 1) WITH NOWAIT
GO
IF  EXISTS (SELECT * FROM sysobjects WHERE id = OBJECT_ID(N'[dbo].[logAlertMessages]') AND type in (N'U'))
DROP TABLE [dbo].[logAlertMessages]
GO
CREATE TABLE [dbo].[logAlertMessages]
(
	[id]										[int] IDENTITY (1, 1)NOT NULL,
	[project_id]								[smallint]			NULL,
	[instance_id]								[smallint]			NULL,
	[event_date]								[datetime]			NOT NULL,
	[module]									[nvarchar](32)		NOT NULL,
	[parameters]								[nvarchar](512)			NULL,
	[event_name]								[nvarchar](256)		NOT NULL,
	[message]									[nvarchar](max)		NULL,
	[send_email_to]								[nvarchar](max)		NULL,
	[event_type]								[smallint]			NULL,
	[event_type_desc]							AS (CASE [event_type]	WHEN 1 THEN 'Alert' 
																		WHEN 2 THEN 'Job'
																		WHEN 3 THEN 'Report'
																		ELSE NULL END),
	[is_email_sent]								[bit]				NOT NULL CONSTRAINT [DF_logAlertMessages_is_email_sent] DEFAULT (0),
	CONSTRAINT [PK_logAlertMessages] PRIMARY KEY  CLUSTERED 
	(
		[id]
	) ON [FG_Statistics_Data],
	CONSTRAINT [FK_logAlertMessages_catalogProjects] FOREIGN KEY 
	(
		[project_id]
	) 
	REFERENCES [dbo].[catalogProjects] 
	(
		[id]
	),
	CONSTRAINT [FK_logAlertMessages_catalogInstanceNames] FOREIGN KEY 
	(
		[instance_id],
		[project_id]
	) 
	REFERENCES [dbo].[catalogInstanceNames] 
	(
		[id],
		[project_id]
	)

) ON [FG_Statistics_Data]
GO


CREATE INDEX [IX_logAlertMessages_ProjecteID] ON [dbo].[logAlertMessages]([project_id]) ON [FG_Statistics_Index]
GO
CREATE INDEX [IX_logAlertMessages_Module_EventName] ON [dbo].[logAlertMessages]([instance_id], [project_id], [module], [event_name], [event_date]) ON [FG_Statistics_Index]
GO
