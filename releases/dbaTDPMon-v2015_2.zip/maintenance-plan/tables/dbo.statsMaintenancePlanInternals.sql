-- ============================================================================
-- Author			 : Andrei STEFAN (danandrei.stefan@gmail.com)
-- Create date		 : 06.02.2015
-- Module			 : Database Analysis & Performance Monitoring
-- ============================================================================
-- table will contain actions made against schema objects, in order to track/troubleshoot
-----------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------
--
-----------------------------------------------------------------------------------------------------
RAISERROR('Create table: [dbo].[statsMaintenancePlanInternals]', 10, 1) WITH NOWAIT
GO
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[statsMaintenancePlanInternals]') AND type in (N'U'))
DROP TABLE [dbo].[statsMaintenancePlanInternals]
GO
CREATE TABLE [dbo].[statsMaintenancePlanInternals]
(
	[id]				[bigint] IDENTITY (1, 1)NOT NULL,
	[event_date_utc]	[datetime]				NOT NULL CONSTRAINT [DF_statsMaintenancePlanInternals_EventDateUTC] DEFAULT (GETUTCDATE()),
	[session_id]		[smallint]				NOT NULL CONSTRAINT [DF_statsMaintenancePlanInternals_SessionID] DEFAULT (@@SPID),
	[name]				[sysname]				NOT NULL,
	[value1]			[sysname]				NULL,
	[value2]			[sysname]				NULL,
	[value3]			[sysname]				NULL,
	[value4]			[sysname]				NULL,
	CONSTRAINT [PK_statsMaintenancePlanInternals] PRIMARY KEY  CLUSTERED 
	(
		[id]
	) ON [FG_Statistics_Data]
) ON [FG_Statistics_Data]
GO

CREATE INDEX [IX_statsMaintenancePlanInternals_SessionID_Name] ON [dbo].[statsMaintenancePlanInternals]
		([session_id], [name]) 
	INCLUDE 
		([value1]) 
	ON [FG_Statistics_Index]
GO

CREATE INDEX [IX_statsMaintenancePlanInternals_Name] ON [dbo].[statsMaintenancePlanInternals]
		([name], [value1])
	ON [FG_Statistics_Index]
GO