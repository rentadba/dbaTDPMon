RAISERROR('Create procedure: [dbo].[usp_mpDatabaseConsistencyCheck]', 10, 1) WITH NOWAIT
GO
IF  EXISTS (
	    SELECT * 
	      FROM sysobjects 
	     WHERE id = OBJECT_ID(N'[dbo].[usp_mpDatabaseConsistencyCheck]') 
	       AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_mpDatabaseConsistencyCheck]
GO

-----------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_mpDatabaseConsistencyCheck]
		@SQLServerName			[sysname]=@@SERVERNAME,
		@DBName					[sysname],
		@TableSchema			[sysname]	=  '%',
		@TableName				[sysname]   =  '%',
		@flgActions				[smallint]	=   44,
		@flgOptions				[smallint]	=    3,
		@executionLevel			[tinyint]	=    0,
		@DebugMode				[bit]		=    0
AS

-- ============================================================================
-- Author			 : Andrei STEFAN (danandrei.stefan@gmail.com)
-- Create date		 : 08.01.2010
-- Module			 : Database Maintenance Plan 
--					 : SQL Server 2000/2005/2008/2008R2/2012+
-- Description		 : Consistency Checks
-- ============================================================================
-----------------------------------------------------------------------------------------
-- Input Parameters:
--		@SQLServerName	- name of SQL Server instance to analyze
--		@DBName			- database to be analyzed
--		@TableSchema	- schema that current table belongs to
--		@TableName		- specify % for all tables or a table name to be analyzed
--		@flgActions		1	- perform database consistency check (DBCC CHECKDB)
--							  should be performed monthly
--						2	- perform table consistency check (DBCC CHECKTABLE)
--							  should be performed once at 2 weeks
--					    4   - perform consistency check of disk space allocation structures (DBCC CHECKALLOC) (default)
--							  should be performed weekly
--					    8   - perform consistency check of catalogs (DBCC CHECKCATALOG) (default)
--							  should be performed weekly
--					   16   - perform consistency check of table constraints (DBCC CHECKCONSTRAINTS)
--							  should be performed once at 2 weeks
--					   32   - perform consistency check of table identity value (DBCC CHECKIDENT) (default)
--							  should be performed weekly
--					   64   - perform correction to space usage (DBCC UPDATEUSAGE)
--							  should be performed once at 2 weeks
--					  128 	- Cleaning wasted space in Database (variable-length column) (DBCC CHECKTABLE)
--							  should be performed once a year
--		@flgOptions	    1	- run DBCC CHECKDB/DBCC CHECKTABLE using PHYSICAL_ONLY (default). 
--							  by default DBCC CHECKDB is doing all consistency checks and for a VLDB it may take a very long time
--					    2  - use NOINDEX when running DBCC CHECKTABLE. Index consistency errors are not critical (default)
--					   32  - Stop execution if an error occurs. Default behaviour is to print error messages and continue execution
--		@DebugMode			- 1 - print dynamic SQL statements / 0 - no statements will be displayed
-----------------------------------------------------------------------------------------
-- Return : 
-- 1 : Succes  -1 : Fail 
-----------------------------------------------------------------------------------------
/*
	--usage sample
	EXEC [dbo].[usp_mpDatabaseConsistencyCheck]	@SQLServerName			= @@SERVERNAME,
												@DBName					= 'dbSQLTools',
												@TableSchema			= 'dbo',
												@TableName				= '%',
												@flgActions				= DEFAULT,
												@flgOptions				= DEFAULT,
												@DebugMode				= DEFAULT
*/

DECLARE		@queryToRun  					[nvarchar](2048),
			@queryParameters				[nvarchar](512),
			@tmpSQL		  					[nvarchar](2048),
			@tmpServer						[varchar](256),
			@CurrentTableSchema				[sysname],
			@CurrentTableName 				[sysname],
			@eventName						[nvarchar](512),
			@DBCCCheckTableBatchSize 		[int],
			@ReturnValue					[int]

SET NOCOUNT ON

---------------------------------------------------------------------------------------------
--get destination server running version/edition
DECLARE		@serverEdition					[sysname],
			@serverVersionStr				[sysname],
			@serverVersionNum				[numeric](9,6),
			@nestedExecutionLevel			[tinyint]

SET @nestedExecutionLevel = @executionLevel + 1
EXEC [dbo].[usp_getSQLServerVersion]	@sqlServerName			= @SQLServerName,
										@serverEdition			= @serverEdition OUT,
										@serverVersionStr		= @serverVersionStr OUT,
										@serverVersionNum		= @serverVersionNum OUT,
										@executionLevel			= @nestedExecutionLevel,
										@debugMode				= @DebugMode
---------------------------------------------------------------------------------------------

SET @DBCCCheckTableBatchSize = 65536
SET @ReturnValue			 = 1
SET @CurrentTableSchema		 = @TableSchema

---------------------------------------------------------------------------------------------
--create temporary tables that will be used 
---------------------------------------------------------------------------------------------
IF object_id('tempdb..#databaseTableList') IS NOT NULL 
	DROP TABLE #databaseTableList

CREATE TABLE #databaseTableList(
								[table_schema]	[sysname]	NULL,
								[table_name]	[sysname]	NULL
								)
CREATE INDEX IX_databaseTableList_TableName ON #databaseTableList([table_name])


---------------------------------------------------------------------------------------------
SET @tmpServer='[' + @SQLServerName + '].[' + @DBName + '].[dbo].[sp_executesql]'
---------------------------------------------------------------------------------------------

IF @flgActions & 2 = 2 OR @flgActions & 16 = 16 OR @flgActions & 64 = 64 OR @flgActions & 128 = 128
	begin
		--get table list that will be analyzed including materialized views
		SET @queryToRun = N''
		IF @serverVersionNum >= 9
			SET @queryToRun = @queryToRun + N'	SELECT DISTINCT [TABLE_SCHEMA], [TABLE_NAME]
										FROM [' + @DBName + '].INFORMATION_SCHEMA.TABLES 
										WHERE	[TABLE_TYPE]=''BASE TABLE'' 
												AND [TABLE_NAME] LIKE ''' + @TableName + '''
												AND [TABLE_SCHEMA] LIKE ''' + @TableSchema + '''

										UNION ALL			

										SELECT DISTINCT sch.[name] AS TABLE_SCHEMA, obj.[name] AS TABLE_NAME
										FROM [' + @DBName + '].sys.indexes idx
										INNER JOIN [' + @DBName + '].sys.objects obj ON obj.[object_id] = idx.[object_id]
										INNER JOIN [' + @DBName + '].sys.schemas sch ON sch.[schema_id] = obj.[schema_id]
										WHERE obj.[type]= ''V''
												AND obj.[name] LIKE ''' + @TableName + '''
												AND sch.[name] LIKE ''' + @TableSchema + '''
									'
		ELSE
			SET @queryToRun = @queryToRun + N'	SELECT DISTINCT [TABLE_SCHEMA], [TABLE_NAME]
										FROM [' + @DBName + '].INFORMATION_SCHEMA.TABLES 
										WHERE	[TABLE_TYPE]=''BASE TABLE'' 
												AND [TABLE_NAME] LIKE ''' + @TableName + '''
												AND [TABLE_SCHEMA] LIKE ''' + @TableSchema + '''

										UNION ALL			

										SELECT DISTINCT sch.[name] AS TABLE_SCHEMA, obj.[name] AS TABLE_NAME
										FROM [' + @DBName + ']..sysindexes idx
										INNER JOIN [' + @DBName + ']..sysobjects obj ON obj.[id] = idx.[id]
										INNER JOIN [' + @DBName + ']..sysusers sch ON sch.[uid] = obj.[uid]
										WHERE obj.[type]= ''V''
												AND obj.[name] LIKE ''' + @TableName + '''
												AND sch.[name] LIKE ''' + @TableSchema + '''
									'

		SET @queryToRun = [dbo].[ufn_formatSQLQueryForLinkedServer](@SQLServerName, @queryToRun)
		IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 0, @stopExecution=0

		DELETE FROM #databaseTableList
		INSERT	INTO #databaseTableList([table_schema], [table_name])
				EXEC (@queryToRun)
	end

--------------------------------------------------------------------------------------------------
--
--------------------------------------------------------------------------------------------------
IF @serverVersionNum >= 9
	SET @tmpSQL = N'BEGIN TRY
						EXEC @tmpServer @queryToRun
					END TRY

					BEGIN CATCH
						DECLARE @strMessage [nvarchar](4000)
						DECLARE   @flgRaiseErrorAndStop [bit]
								, @errorString			[nvarchar](max)

						SET @errorString = ERROR_MESSAGE()
						SET @flgRaiseErrorAndStop = @flgOptions & 32
						SET @strMessage=N''--		ERROR: An error occured while checking database consistency.''

						EXEC [dbo].[usp_logMessageFormatAndRaise]	@sqlServerName			= @sqlServerName,
																	@module					= ''dbo.usp_mpDatabaseConsistencyCheck'',
																	@eventName				= @eventName, 
																	@customMessage			= @strMessage, 
																	@errorString			= @errorString,
																	@queryExecuted			= @queryToRun,
																	@flgRaiseErrorAndStop	= @flgRaiseErrorAndStop
					END CATCH'
ELSE
	SET @tmpSQL = N'EXEC @tmpServer @queryToRun
					IF @@ERROR<>0
						begin
							IF @flgOptions & 32 = 32
								EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @stopExecution=1
							ELSE
								EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun
						end'
SET @queryParameters=N'@tmpServer [nvarchar](512), @queryToRun [nvarchar](2048), @flgOptions [int],  @eventName [nvarchar](512), @sqlServerName [sysname]'


--------------------------------------------------------------------------------------------------
--database consistency check
--------------------------------------------------------------------------------------------------
IF @flgActions & 1 = 1
	begin
		IF @executionLevel=0 EXEC [dbo].[usp_logPrintMessage] @customMessage = '<separator-line>', @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

		SET @queryToRun=N'Database consistency check ' + CASE WHEN @flgOptions & 1 = 1 THEN '(PHYSICAL_ONLY)' ELSE '' END + '...' + ' [' + @DBName + ']'
		EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

		SET @queryToRun = N''
		SET @queryToRun = @queryToRun + N'DBCC CHECKDB(''' + @DBName + ''') ' + CASE WHEN @flgOptions & 1 = 1 THEN 'WITH PHYSICAL_ONLY' ELSE '' END
		IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 0, @stopExecution=0

		SET @eventName= '[' + @DBName + ']: Database Maintenance Error - ' + 'Consistency Check'

		EXEC sp_executesql @tmpSQL, @queryParameters, @tmpServer  = @tmpServer
													, @queryToRun = @queryToRun
													, @flgOptions = @flgOptions
													, @eventName  = @eventName
													, @sqlServerName = @SQLServerName
	end			


--------------------------------------------------------------------------------------------------
--tables and views consistency check
--------------------------------------------------------------------------------------------------
IF @flgActions & 2 = 2
	begin
		IF @executionLevel=0 EXEC [dbo].[usp_logPrintMessage] @customMessage = '<separator-line>', @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

		SET @queryToRun=N'Tables/views consistency check ' + CASE WHEN @flgOptions & 1 = 1 THEN '(PHYSICAL_ONLY)' ELSE '' END + CASE WHEN @flgOptions & 2 = 2 THEN '(NOINDEX)' ELSE '' END + '...' + ' [' + @DBName + ']'
		EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

		DECLARE crsTableList CURSOR FOR	SELECT [table_schema], [table_name] 
										FROM #databaseTableList	
										ORDER BY [table_name]
		OPEN crsTableList
		FETCH NEXT FROM crsTableList INTO @CurrentTableSchema, @CurrentTableName
		WHILE @@FETCH_STATUS = 0
			begin
				SET @queryToRun=N'[' + @CurrentTableSchema + '].[' + @CurrentTableName + ']'
				EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 2, @stopExecution=0

				SET @queryToRun = N''
				SET @queryToRun = @queryToRun + N'DBCC CHECKTABLE(''[' + @CurrentTableSchema + '].[' + RTRIM(@CurrentTableName) + ']''' + CASE WHEN @flgOptions & 2 = 2 THEN ', NOINDEX' ELSE '' END + ') WITH DATA_PURITY'
				IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 0, @stopExecution=0

				SET @eventName= '[' + @DBName + ']: Database Maintenance Error - ' + 'Tables/views consistency check - ' + '[' + @CurrentTableSchema + '].[' + RTRIM(@CurrentTableName) + ']'

				EXEC sp_executesql @tmpSQL, @queryParameters, @tmpServer  = @tmpServer
															, @queryToRun = @queryToRun
															, @flgOptions = @flgOptions
															, @eventName  = @eventName
															, @sqlServerName = @SQLServerName
					
				FETCH NEXT FROM crsTableList INTO @CurrentTableSchema, @CurrentTableName
			end
		CLOSE crsTableList
		DEALLOCATE crsTableList
	end			


--------------------------------------------------------------------------------------------------
--allocation structures consistency check
--------------------------------------------------------------------------------------------------
IF @flgActions & 4 = 4
	begin
		IF @executionLevel=0 EXEC [dbo].[usp_logPrintMessage] @customMessage = '<separator-line>', @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

		SET @queryToRun=N'Allocation structures consistency check ...' + ' [' + @DBName + ']'
		EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

		SET @queryToRun = N''
		SET @queryToRun = @queryToRun + N'DBCC CHECKALLOC(''' + @DBName + ''')'
		IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 0, @stopExecution=0

		SET @eventName= '[' + @DBName + ']: Database Maintenance Error - ' + 'Allocation Structures Consistency Check'

		EXEC sp_executesql @tmpSQL, @queryParameters, @tmpServer  = @tmpServer
													, @queryToRun = @queryToRun
													, @flgOptions = @flgOptions
													, @eventName  = @eventName
													, @sqlServerName = @SQLServerName
	end			


--------------------------------------------------------------------------------------------------
--catalogs consistency check
--------------------------------------------------------------------------------------------------
IF @flgActions & 8 = 8
	begin
		IF @executionLevel=0 EXEC [dbo].[usp_logPrintMessage] @customMessage = '<separator-line>', @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

		SET @queryToRun=N'Catalogs consistency check ...' + ' [' + @DBName + ']'
		EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

		SET @queryToRun = N''
		SET @queryToRun = @queryToRun + N'DBCC CHECKCATALOG(''' + @DBName + ''')'
		IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 0, @stopExecution=0

		SET @eventName= '[' + @DBName + ']: Database Maintenance Error - ' + 'Catalogs Consistency Check'

		EXEC sp_executesql @tmpSQL, @queryParameters, @tmpServer  = @tmpServer
													, @queryToRun = @queryToRun
													, @flgOptions = @flgOptions
													, @eventName  = @eventName
													, @sqlServerName = @SQLServerName
	end			


--------------------------------------------------------------------------------------------------
--table constraints consistency check
--------------------------------------------------------------------------------------------------
IF @flgActions & 16 = 16
	begin
		IF @executionLevel=0 EXEC [dbo].[usp_logPrintMessage] @customMessage = '<separator-line>', @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

		SET @queryToRun=N'Table constraints consistency check ...' + ' [' + @DBName + ']'
		EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
		
		DECLARE crsTableList CURSOR FOR	SELECT [table_schema], [table_name] 
										FROM #databaseTableList	
										ORDER BY [table_name]
		OPEN crsTableList
		FETCH NEXT FROM crsTableList INTO @CurrentTableSchema, @CurrentTableName
		WHILE @@FETCH_STATUS = 0
			begin
				SET @queryToRun=N'[' + @CurrentTableSchema + '].[' + @CurrentTableName + ']'
				EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 2, @stopExecution=0

				SET @queryToRun = N''
				SET @queryToRun = @queryToRun + N'DBCC CHECKCONSTRAINTS(''[' + @CurrentTableSchema + '].[' + RTRIM(@CurrentTableName) + ']'')'
				IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 0, @stopExecution=0

				SET @eventName= '[' + @DBName + ']: Database Maintenance Error - ' + 'Table Constraints Consistency Check - ' + '[' + @CurrentTableSchema + '].[' + RTRIM(@CurrentTableName) + ']'

				EXEC sp_executesql @tmpSQL, @queryParameters, @tmpServer  = @tmpServer
															, @queryToRun = @queryToRun
															, @flgOptions = @flgOptions
															, @eventName  = @eventName
															, @sqlServerName = @SQLServerName
					
				FETCH NEXT FROM crsTableList INTO @CurrentTableSchema, @CurrentTableName
			end
		CLOSE crsTableList
		DEALLOCATE crsTableList
	end			


--------------------------------------------------------------------------------------------------
--table identity value consistency check
--------------------------------------------------------------------------------------------------
IF @flgActions & 32 = 32
	begin
		IF @executionLevel=0 EXEC [dbo].[usp_logPrintMessage] @customMessage = '<separator-line>', @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

		SET @queryToRun=N'Table identity value consistency check ...' + ' [' + @DBName + ']'
		EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
		
		---------------------------------------------------------------------------------------------
		--create temporary tables that will be used 
		---------------------------------------------------------------------------------------------
		IF object_id('tempdb..#databaseTableListIdent') IS NOT NULL 
			DROP TABLE #databaseTableListIdent

		CREATE TABLE #databaseTableListIdent(
												[table_schema]	[sysname],
												[table_name]	[sysname]
											)
		CREATE INDEX IX_databaseTableListIdent_TableName ON #databaseTableListIdent([table_name])


		--get table list that will be analyzed. only tables with identity columns
		SET @queryToRun = N''
		IF @serverVersionNum >= 9
			SET @queryToRun = @queryToRun + N'	SELECT DISTINCT sch.[name] AS [table_schema], obj.[name] AS [table_name]
										FROM [' + @DBName + '].sys.objects obj
										INNER JOIN [' + @DBName + '].sys.schemas sch ON sch.[schema_id] = obj.[schema_id]
										WHERE obj.[type] IN (''U'')
												AND obj.[object_id] IN (
																	SELECT [object_id]
																	FROM [' + @DBName + '].sys.columns
																	WHERE [is_identity] = 1
																	)
												AND obj.[name] LIKE ''' + @TableName + '''
												AND sch.[name] LIKE ''' + @TableSchema + ''''
		ELSE
			SET @queryToRun = @queryToRun + N'SELECT DISTINCT sch.[name] AS [table_schema], obj.[name] AS [table_name]
										FROM  [' + @DBName + ']..sysobjects obj
										INNER JOIN  [' + @DBName + ']..sysusers sch ON sch.[uid] = obj.[uid]
										WHERE obj.[type] IN (''U'')
												AND obj.[id] IN (
																SELECT [id]
																FROM  [' + @DBName + ']..syscolumns
																WHERE [autoval] is not null
																)
												AND obj.[name] LIKE ''' + @TableName + '''
												AND sch.[name] LIKE ''' + @TableSchema + ''''			
				
		SET @queryToRun = [dbo].[ufn_formatSQLQueryForLinkedServer](@SQLServerName, @queryToRun)
		IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 0, @stopExecution=0

		DELETE FROM #databaseTableListIdent
		INSERT	INTO #databaseTableListIdent([table_schema], [table_name])
				EXEC (@queryToRun)

		DECLARE crsTableList CURSOR FOR	SELECT [table_schema], [table_name] 
										FROM #databaseTableListIdent	
										ORDER BY [table_name]
		OPEN crsTableList
		FETCH NEXT FROM crsTableList INTO @CurrentTableSchema, @CurrentTableName
		WHILE @@FETCH_STATUS = 0
			begin
				SET @queryToRun=N'[' + @CurrentTableSchema + '.[' + @CurrentTableName + ']'
				EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 2, @stopExecution=0

				SET @queryToRun = N''
				SET @queryToRun = @queryToRun + N'DBCC CHECKIDENT(''[' + @CurrentTableSchema + '].[' + RTRIM(@CurrentTableName) + ']'')'
				IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 0, @stopExecution=0

				SET @eventName= '[' + @DBName + ']: Database Maintenance Error - ' + 'Table Identity Value Consistency Check - ' + '[' + @CurrentTableSchema + '].[' + RTRIM(@CurrentTableName) + ']'

				EXEC sp_executesql @tmpSQL, @queryParameters, @tmpServer  = @tmpServer
															, @queryToRun = @queryToRun
															, @flgOptions = @flgOptions
															, @eventName  = @eventName
															, @sqlServerName = @SQLServerName
					
				FETCH NEXT FROM crsTableList INTO @CurrentTableSchema, @CurrentTableName
			end
		CLOSE crsTableList
		DEALLOCATE crsTableList

		IF object_id('tempdb..#databaseTableListIdent') IS NOT NULL 
			DROP TABLE #databaseTableListIdent
	end			


--------------------------------------------------------------------------------------------------
--correct space usage
--------------------------------------------------------------------------------------------------
IF @flgActions & 64 = 64
	begin
		IF @executionLevel=0 EXEC [dbo].[usp_logPrintMessage] @customMessage = '<separator-line>', @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

		SET @queryToRun=N'Update space usage...' + ' [' + @DBName + ']'
		EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

		IF @TableName='%' 
			begin
				SET @queryToRun = N''
				SET @queryToRun = @queryToRun + N'DBCC UPDATEUSAGE(''' + @DBName + ''')'
				IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 0, @stopExecution=0

				SET @eventName= '[' + @DBName + ']: Database Maintenance Error - ' + 'Update space usage'

				EXEC sp_executesql @tmpSQL, @queryParameters, @tmpServer  = @tmpServer
															, @queryToRun = @queryToRun
															, @flgOptions = @flgOptions
															, @eventName  = @eventName
															, @sqlServerName = @SQLServerName
			end
		ELSE
			begin
				DECLARE crsTableList CURSOR FOR	SELECT [table_schema], [table_name] 
												FROM #databaseTableList	
												ORDER BY [table_name]
				OPEN crsTableList
				FETCH NEXT FROM crsTableList INTO @CurrentTableSchema, @CurrentTableName
				WHILE @@FETCH_STATUS = 0
					begin
						SET @queryToRun=N'--	[' + @CurrentTableSchema + '].[' + @CurrentTableName + ']'
						EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 2, @stopExecution=0

						SET @queryToRun = N''
						SET @queryToRun = @queryToRun + N'DBCC UPDATEUSAGE(''' + @DBName + ''', ''[' + @CurrentTableSchema + '].[' + RTRIM(@CurrentTableName) + ']'')'
						IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 0, @stopExecution=0

						SET @eventName= '[' + @DBName + ']: Database Maintenance Error - ' + 'Update space usage - ' + '[' + @CurrentTableSchema + '].[' + RTRIM(@CurrentTableName) + ']'

						EXEC sp_executesql @tmpSQL, @queryParameters, @tmpServer  = @tmpServer
																	, @queryToRun = @queryToRun
																	, @flgOptions = @flgOptions
																	, @eventName  = @eventName
																	, @sqlServerName = @SQLServerName

						FETCH NEXT FROM crsTableList INTO @CurrentTableSchema, @CurrentTableName
					end
				CLOSE crsTableList
				DEALLOCATE crsTableList
			end
	end			


--------------------------------------------------------------------------------------------------
--		Cleaning wasted space in Database
--		DBCC CLEANTABLE reclaims space after a variable-length column is dropped. 
--		A variable-length column can be one of the following data types:  varchar, nvarchar, varchar(max),
--		nvarchar(max), varbinary, varbinary(max), text, ntext, image, sql_variant, and xml. 
--		The command does not reclaim space after a fixed-length column is dropped.

--		Best Practices
--		DBCC CLEANTABLE should not be executed as a routine maintenance task. 
--		Instead, use DBCC CLEANTABLE after you make significant changes to variable-length columns in 
--		a table or indexed view and you need to immediately reclaim the unused space. 
--		Alternatively, you can rebuild the indexes on the table or view; however, doing so is a more 
--		resource-intensive operation.
--------------------------------------------------------------------------------------------------
IF @flgActions & 128 = 128
	begin
		IF @executionLevel=0 EXEC [dbo].[usp_logPrintMessage] @customMessage = '<separator-line>', @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

		SET @queryToRun=N'Cleaning wasted space in variable length columns...' + ' [' + @DBName + ']'
		EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

		DECLARE crsTableList CURSOR FOR	SELECT [table_schema], [table_name] 
										FROM #databaseTableList	
										ORDER BY [table_name]
		OPEN crsTableList
		FETCH NEXT FROM crsTableList INTO @CurrentTableSchema, @CurrentTableName
		WHILE @@FETCH_STATUS = 0
			begin
				SET @queryToRun=N'[' + @CurrentTableSchema + '].[' + @CurrentTableName + ']'
				EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 2, @stopExecution=0

				SET @queryToRun = N''
				SET @queryToRun = @queryToRun + N'DBCC CLEANTABLE(''' + @DBName + ''', ''[' + @CurrentTableSchema + '].[' + RTRIM(@CurrentTableName) + ']'', ' + CAST(@DBCCCheckTableBatchSize AS [nvarchar]) + ')'
				IF @DebugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 0, @stopExecution=0

				SET @eventName= '[' + @DBName + ']: Database Maintenance Error - ' + 'Clean wasted space - ' + '[' + @CurrentTableSchema + '].[' + RTRIM(@CurrentTableName) + ']'

				EXEC sp_executesql @tmpSQL, @queryParameters, @tmpServer  = @tmpServer
															, @queryToRun = @queryToRun
															, @flgOptions = @flgOptions
															, @eventName  = @eventName
															, @sqlServerName = @SQLServerName
					
				FETCH NEXT FROM crsTableList INTO @CurrentTableSchema, @CurrentTableName
			end
		CLOSE crsTableList
		DEALLOCATE crsTableList
	end

RETURN @ReturnValue
GO
