RAISERROR('Create procedure: [dbo].[usp_mpDatabaseBackupCleanup]', 10, 1) WITH NOWAIT
GO
IF  EXISTS (
	    SELECT * 
	      FROM sysobjects 
	     WHERE [id] = OBJECT_ID(N'[dbo].[usp_mpDatabaseBackupCleanup]') 
	       AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_mpDatabaseBackupCleanup]
GO

-----------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_mpDatabaseBackupCleanup]
		@sqlServerName			[sysname],
		@dbName					[sysname],
		@backupLocation			[nvarchar](1024)=NULL,	/*  disk only: local or UNC */
		@backupFileExtension	[nvarchar](8),			/*  BAK - cleanup full/incremental database backup
															TRN - cleanup transaction log backup
														*/
		@flgOptions				[smallint]	= 384,		/* 32 - Stop execution if an error occurs. Default behaviour is to print error messages and continue execution
														  128 - when performing cleanup, delete also orphans diff and log backups, when cleanup full database backups(default)
														  256 - for +2k5 versions, use xp_delete_file option
														*/
		@retentionDays			[int]		= 14,
		@executionLevel			[tinyint]	=  0,
		@debugMode				[bit]		=  0
AS

-- ============================================================================
-- Author			 : Andrei STEFAN (danandrei.stefan@gmail.com)
-- Create date		 : 2004-2006 / review on 2015.03.10
-- Module			 : Database Maintenance Plan 
-- Description		 : Optimization and Maintenance Checks
-- ============================================================================

------------------------------------------------------------------------------------------------------------------------------------------
--returns: 0 = success, >0 = failure

DECLARE		@queryToRun  					[nvarchar](2048),
			@queryParameters				[nvarchar](512),
			@tmpSQL		  					[nvarchar](2048),
			@tmpServer						[varchar](256),
			@eventName						[nvarchar](512),
			@nestedExecutionLevel			[tinyint]

DECLARE		@backupFileName					[nvarchar](1024),
			@serverEdition					[sysname],
			@serverVersionStr				[sysname],
			@serverVersionNum				[numeric](9,6),
			@errorCode						[int],
			@maxAllowedDate					[datetime]

DECLARE		@lastFullBackupSetIDGotDeleted	[int], 
			@lastFullBackupSetIDRemaining	[int]

-----------------------------------------------------------------------------------------
SET NOCOUNT ON

-----------------------------------------------------------------------------------------
IF @executionLevel=0
	EXEC [dbo].[usp_logPrintMessage] @customMessage = '<separator-line>', @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 0, @stopExecution=0

SET @queryToRun= 'Cleanup backup files for database: ' + ' [' + @dbName + ']'
EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 0, @stopExecution=0

-----------------------------------------------------------------------------------------
--get destination server running version/edition
EXEC [dbo].[usp_getSQLServerVersion]	@sqlServerName		= @sqlServerName,
										@serverEdition		= @serverEdition OUT,
										@serverVersionStr	= @serverVersionStr OUT,
										@serverVersionNum	= @serverVersionNum OUT,
										@executionLevel		= @executionLevel,
										@debugMode			= @debugMode
										
-----------------------------------------------------------------------------------------
SET @maxAllowedDate = DATEADD(dd, -@retentionDays, GETDATE())

--------------------------------------------------------------------------------------------------
SET @eventName= '[' + @dbName + ']: Database Backup Cleanup Error'
IF @serverVersionNum >= 9
	SET @tmpSQL = N'BEGIN TRY
						EXEC @tmpServer @queryToRun
						SET @errorCode = 0
					END TRY

					BEGIN CATCH
						DECLARE @strMessage [nvarchar](4000)
						DECLARE   @flgRaiseErrorAndStop [bit]
								, @errorString			[nvarchar](max)

						SET @errorString = ERROR_MESSAGE()
						SET @errorCode = ERROR_NUMBER()
						IF LEFT(@errorString, 2)=''--'' 
							SET @errorString = LTRIM(SUBSTRING(@errorString, 3, LEN(@errorString)))

						SET @flgRaiseErrorAndStop = @flgOptions & 32
						SET @strMessage=N''--		ERROR: An error occured while running database backup cleanup.''

						EXEC [dbo].[usp_logMessageFormatAndRaise]	@sqlServerName			= @sqlServerName,
																	@module					= ''dbo.usp_mpDatabaseBackupCleanup'',
																	@eventName				= @eventName, 
																	@customMessage			= @strMessage, 
																	@errorString			= @errorString,
																	@queryExecuted			= @queryToRun,
																	@flgRaiseErrorAndStop	= @flgRaiseErrorAndStop
						EXEC [dbo].[usp_logPrintMessage] @customMessage = @errorString, @raiseErrorAsPrint = 1, @messagRootLevel = 0, @messageTreelevel = 1, @stopExecution=1
					END CATCH'
ELSE
	SET @tmpSQL = N'EXEC @tmpServer @queryToRun
					SET @errorCode=@@ERROR
					IF @errorCode<>0
						begin
							IF @flgOptions & 32 = 32
								EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @stopExecution=1
							ELSE
								EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun
						end'
SET @queryParameters=N'@tmpServer [nvarchar](512), @queryToRun [nvarchar](2048), @flgOptions [int],  @eventName [nvarchar](512), @sqlServerName [sysname], @errorCode [int] OUTPUT'


-----------------------------------------------------------------------------------------
--for +2k5 versions, will use xp_delete_file
SET @errorCode=0
IF @serverVersionNum>=9 AND @flgOptions & 256 = 256
	begin
		SET @queryToRun = N'EXEC master.dbo.xp_delete_file 0, N''' + @backupLocation + ''', N''' + @backupFileExtension + ''', N''' + CONVERT([varchar](20), @maxAllowedDate, 120) + ''', 0'
		SET @tmpServer='[' + @@SERVERNAME + '].[' + DB_NAME() + '].[dbo].[sp_executesql]'
		IF @debugMode = 1 EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0

		EXEC sp_executesql @tmpSQL, @queryParameters, @tmpServer  = @tmpServer
													, @queryToRun = @queryToRun
													, @flgOptions = @flgOptions
													, @eventName  = @eventName
													, @sqlServerName = @sqlServerName
													, @errorCode = @errorCode OUT
	end

-----------------------------------------------------------------------------------------
-- when performing cleanup, delete also orphans diff and log backups, when cleanup full database backups(default)
IF @flgOptions & 128 = 128
	begin
		SET @lastFullBackupSetIDGotDeleted = NULL
		SET @lastFullBackupSetIDRemaining  = NULL

		SELECT TOP 1 @lastFullBackupSetIDGotDeleted = bs.[backup_set_id]
		FROM [msdb].[dbo].[backupset] bs
		INNER JOIN [msdb].[dbo].[backupmediafamily] bmf ON bmf.[media_set_id]=bs.[media_set_id]
		WHERE	bs.[backup_start_date] <= @maxAllowedDate
				AND bs.[database_name] = @dbName
				AND bs.[type]='D'
		ORDER BY bs.[backup_start_date] DESC

		IF @lastFullBackupSetIDGotDeleted IS NOT NULL
			begin
				SELECT TOP 1 @lastFullBackupSetIDRemaining = bs.[backup_set_id]
				FROM [msdb].[dbo].[backupset] bs
				INNER JOIN [msdb].[dbo].[backupmediafamily] bmf ON bmf.[media_set_id]=bs.[media_set_id]
				WHERE	bs.[backup_start_date] > @maxAllowedDate
						AND bs.[database_name] = @dbName
						AND bs.[type]='D'
				ORDER BY bs.[backup_start_date] ASC

				IF @lastFullBackupSetIDRemaining IS NULL
					SET @lastFullBackupSetIDGotDeleted=NULL
			end
	end
	
-----------------------------------------------------------------------------------------
--in case of previous errors or 2k version, will use "standard" delete file
IF (@flgOptions & 256 = 0) OR (@errorCode<>0 AND @flgOptions & 256 = 256) OR (@serverVersionNum < 9) OR (@flgOptions & 128 = 128 AND @lastFullBackupSetIDGotDeleted IS NOT NULL AND @lastFullBackupSetIDRemaining IS NOT NULL)
	begin
		SET @nestedExecutionLevel = @executionLevel + 1
		DECLARE crsCleanupBackupFiles CURSOR FOR	SELECT bmf.[physical_device_name]
													FROM [msdb].[dbo].[backupset] bs
													INNER JOIN [msdb].[dbo].[backupmediafamily] bmf ON bmf.[media_set_id]=bs.[media_set_id]
													WHERE	(   (    bs.[backup_start_date] <= @maxAllowedDate 
																 AND bmf.[physical_device_name] LIKE (@backupLocation + '%.' + @backupFileExtension)
																)
															 OR (    bs.[backup_set_id] >= @lastFullBackupSetIDGotDeleted 
																 AND bs.[backup_set_id] < @lastFullBackupSetIDRemaining
																 AND bs.[database_name] = @dbName
																 AND @flgOptions & 128 = 128
																)
															)														
															AND bmf.[device_type] = 2														
													ORDER BY bs.[backup_start_date] ASC
		OPEN crsCleanupBackupFiles
		FETCH NEXT FROM crsCleanupBackupFiles INTO @backupFileName
		WHILE @@FETCH_STATUS=0
			begin
				EXEC [dbo].[usp_mpDeleteFileOnDisk]	@sqlServerName	= @sqlServerName,
													@fileName		= @backupFileName,
													@executionLevel	= @nestedExecutionLevel,
													@debugMode		= @debugMode
				FETCH NEXT FROM crsCleanupBackupFiles INTO @backupFileName
			end
		CLOSE crsCleanupBackupFiles
		DEALLOCATE crsCleanupBackupFiles
	end
GO
