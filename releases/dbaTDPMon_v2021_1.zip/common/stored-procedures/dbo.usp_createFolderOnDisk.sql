RAISERROR('Create procedure: [dbo].[usp_createFolderOnDisk]', 10, 1) WITH NOWAIT
GO
IF  EXISTS (
	    SELECT * 
	      FROM sysobjects 
	     WHERE id = OBJECT_ID(N'[dbo].[usp_createFolderOnDisk]') 
	       AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[usp_createFolderOnDisk]
GO

CREATE PROCEDURE [dbo].[usp_createFolderOnDisk]
		@sqlServerName			[sysname],
		@folderName				[nvarchar](1024),
		@executionLevel			[tinyint] = 0,
		@debugMode				[bit] = 0
/* WITH ENCRYPTION */
AS

-- ============================================================================
-- Copyright (c) 2004-2015 Dan Andrei STEFAN (danandrei.stefan@gmail.com)
-- ============================================================================
-- Author			 : Dan Andrei STEFAN
-- Create date		 : 04.03.2015
-- Module			 : Database Analysis & Performance Monitoring
-- ============================================================================

DECLARE   @queryToRun				[nvarchar](1024)
		, @serverToRun				[nvarchar](512)
		, @errorCode				[int]

DECLARE	  @serverEdition			[sysname]
		, @serverVersionStr			[sysname]
		, @serverVersionNum			[numeric](9,6)
		, @serverEngine				[int]
		, @nestedExecutionLevel		[tinyint]
		, @warningMessage			[nvarchar](1024)
		, @runWithxpCreateSubdir	[bit]
		, @retryAttempts			[tinyint]
		, @optionXPValue			[int]

SET NOCOUNT ON

/*-------------------------------------------------------------------------------------------------------------------------------*/
IF object_id('#serverPropertyConfig') IS NOT NULL DROP TABLE #serverPropertyConfig
CREATE TABLE #serverPropertyConfig
			(
				[value]			[sysname]	NULL
			)

IF object_id('#fileExists') IS NOT NULL DROP TABLE #fileExists
CREATE TABLE #fileExists
			(
				[file_exists]				[bit]	NULL,
				[file_is_directory]			[bit]	NULL,
				[parent_directory_exists]	[bit]	NULL
			)

/*-------------------------------------------------------------------------------------------------------------------------------*/
IF RIGHT(@folderName, 1)<>'\' SET @folderName = @folderName + N'\'


--checking for invalid characters <>:"'
SET @folderName = [dbo].[ufn_getObjectQuoteName](@folderName, 'filepath')

SET @folderName = [dbo].[ufn_formatPlatformSpecificPath](@sqlServerName, @folderName)

-----------------------------------------------------------------------------------------
--get destination server running version/edition
SET @nestedExecutionLevel = @executionLevel + 1
EXEC [dbo].[usp_getSQLServerVersion]	@sqlServerName			= @sqlServerName,
										@serverEdition			= @serverEdition OUT,
										@serverVersionStr		= @serverVersionStr OUT,
										@serverVersionNum		= @serverVersionNum OUT,
										@serverEngine			= @serverEngine OUT,
										@executionLevel			= @nestedExecutionLevel,
										@debugMode				= @debugMode

IF @serverEngine IN (5, 6, 8)
	begin
		SET @warningMessage = N'Azure managed service (SQL and Managed Instance) does not support OS/file operations.'
		EXEC [dbo].[usp_logPrintMessage] @customMessage = @warningMessage, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
		RETURN
	end

/*-------------------------------------------------------------------------------------------------------------------------------*/
/* check if folderName exists																									 */
IF @sqlServerName=@@SERVERNAME
		SET @queryToRun = N'master.dbo.xp_fileexist ''' + @folderName + ''''
else
	begin
		IF @serverVersionNum < 11	
			SET @queryToRun = N'SELECT * FROM OPENQUERY([' + @sqlServerName + N'], ''SET FMTONLY OFF; EXEC master.dbo.xp_fileexist ''''' + @folderName + ''''';'')x'
		ELSE
			SET @queryToRun = N'SELECT * FROM OPENQUERY([' + @sqlServerName + N'], ''SET FMTONLY OFF; EXEC (''''master.dbo.xp_fileexist ''''''''' + @folderName + ''''''''' '''') WITH RESULT SETS(([File Exists] [int], [File is a Directory] [int], [Parent Directory Exists] [int])) '')x'
	end

IF @debugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
INSERT	INTO #fileExists([file_exists], [file_is_directory], [parent_directory_exists])
		EXEC sp_executesql @queryToRun

SET @warningMessage = N''
IF (SELECT [parent_directory_exists] FROM #fileExists)=0
	begin
		SET @warningMessage = N'WARNING: Root folder does not exists or it is not available.'
		EXEC [dbo].[usp_logPrintMessage] @customMessage = @warningMessage, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
	end

SET @retryAttempts=3

IF (SELECT [file_is_directory] FROM #fileExists)=1
	begin
		IF @debugMode=1	
			begin
				SET @queryToRun = N'Folder already exists.'
				EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
			end
		RETURN
	end
ELSE
	begin
		SET @queryToRun= 'Creating destination folder: "' + @folderName + '"'
		EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 0, @stopExecution=0

		WHILE (SELECT [file_is_directory] FROM #fileExists)=0 AND @retryAttempts > 0
			begin
				SET @runWithxpCreateSubdir = 0
				SET @optionXPValue = 0

				/*-------------------------------------------------------------------------------------------------------------------------------*/
				SET @queryToRun = N'[' + @sqlServerName + '].master.sys.xp_create_subdir N''' + @folderName + ''''
				IF @debugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
				BEGIN TRY
					EXEC sp_executesql @queryToRun
				
					IF @@ERROR=0
						SET @runWithxpCreateSubdir=1
					ELSE
						begin
							/* enable xp_cmdshell configuration option */
							EXEC [dbo].[usp_changeServerOption_xp_cmdshell]   @serverToRun	 = @sqlServerName
																			, @flgAction	 = 1			-- 1=enable | 0=disable
																			, @optionXPValue = @optionXPValue OUTPUT
																			, @debugMode	 = @debugMode

							IF @optionXPValue = 0
								begin
									RETURN 1
								end		
						end
				END TRY
				BEGIN CATCH
					begin
						/* enable xp_cmdshell configuration option */
						EXEC [dbo].[usp_changeServerOption_xp_cmdshell]   @serverToRun	 = @sqlServerName
																		, @flgAction	 = 1			-- 1=enable | 0=disable
																		, @optionXPValue = @optionXPValue OUTPUT
																		, @debugMode	 = @debugMode

						IF @optionXPValue = 0
							begin
								RETURN 1
							end		
					end
				END CATCH

				/*-------------------------------------------------------------------------------------------------------------------------------*/
				/* creating folder   																											 */
				IF @runWithxpCreateSubdir=0
					begin
						SET @queryToRun = N'MKDIR -P "' + @folderName + '"'
						SET @serverToRun = N'[' + @sqlServerName + '].master.dbo.xp_cmdshell'
						IF @debugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
						EXEC @serverToRun @queryToRun , NO_OUTPUT
					end

				/*-------------------------------------------------------------------------------------------------------------------------------*/
				IF @runWithxpCreateSubdir=0
					begin
						/* disable xp_cmdshell configuration option */
						EXEC [dbo].[usp_changeServerOption_xp_cmdshell]   @serverToRun	 = @sqlServerName
																		, @flgAction	 = 0			-- 1=enable | 0=disable
																		, @optionXPValue = @optionXPValue OUTPUT
																		, @debugMode	 = @debugMode

					end


				---------------------------------------------------------------------------------------------
				/* get configuration values - wait/lock timeout */
				DECLARE @queryLockTimeOut [int]
				SELECT	@queryLockTimeOut=[value] 
				FROM	[dbo].[appConfigurations] 
				WHERE	[name] = 'Default lock timeout (ms)'
						AND [module] = 'common'


				SET @queryLockTimeOut = @queryLockTimeOut / 1000
				DECLARE @waitDelay [varchar](16)

				SET @waitDelay = REPLICATE('0', 2-LEN(CAST(@queryLockTimeOut/3600 AS [varchar]))) + CAST(@queryLockTimeOut/3600 AS [varchar]) + ':' + 
								 REPLICATE('0', 2-LEN(CAST((@queryLockTimeOut%3600)/60 AS [varchar]))) + CAST((@queryLockTimeOut%3600)/60 AS [varchar]) + ':' +
								 REPLICATE('0', 2-LEN(CAST(@queryLockTimeOut%60 AS [varchar]))) + CAST(@queryLockTimeOut%60 AS [varchar])

				--wait 5 seconds before
				WAITFOR DELAY @waitDelay

				/*-------------------------------------------------------------------------------------------------------------------------------*/
				/* check if folderName exists																									 */
				IF @sqlServerName=@@SERVERNAME
						SET @queryToRun = N'master.dbo.xp_fileexist ''' + @folderName + ''''
				else
					begin
						IF @serverVersionNum < 11	
							SET @queryToRun = N'SELECT * FROM OPENQUERY([' + @sqlServerName + N'], ''SET FMTONLY OFF; EXEC master.dbo.xp_fileexist ''''' + @folderName + ''''';'')x'
						ELSE
							SET @queryToRun = N'SELECT * FROM OPENQUERY([' + @sqlServerName + N'], ''SET FMTONLY OFF; EXEC (''''master.dbo.xp_fileexist ''''''''' + @folderName + ''''''''' '''') WITH RESULT SETS(([File Exists] [int], [File is a Directory] [int], [Parent Directory Exists] [int])) '')x'
					end

				IF @debugMode=1	EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
				DELETE FROM #fileExists
				INSERT	INTO #fileExists([file_exists], [file_is_directory], [parent_directory_exists])
						EXEC sp_executesql @queryToRun

				IF (SELECT [file_is_directory] FROM #fileExists)=0
					SET @retryAttempts=@retryAttempts - 1
				ELSE
					SET @retryAttempts=0
			end
	end

IF (SELECT [file_is_directory] FROM #fileExists)=0
	begin
		SET @queryToRun = CASE WHEN @warningMessage <> N'' THEN @warningMessage + N' ' ELSE N'' END + N'ERROR: Destination folder cannot be created.'
		EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 1, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=1
		RETURN 1
	end
ELSE
	begin
		SET @queryToRun = N'Folder was successfully created.'
		EXEC [dbo].[usp_logPrintMessage] @customMessage = @queryToRun, @raiseErrorAsPrint = 0, @messagRootLevel = @executionLevel, @messageTreelevel = 1, @stopExecution=0
	end

RETURN 0
GO
